/**
 * Check and Run Migration Script
 * This script checks if the soft delete migration has been run and runs it if needed
 */

const { DataSource } = require('typeorm');
const config = require('../config');

async function checkAndRunMigration() {
  let dataSource;
  
  try {
    console.log('🔍 Checking database migration status...\n');
    
    // Create data source
    dataSource = new DataSource({
      type: config.database.type,
      host: config.database.host,
      port: config.database.port,
      username: config.database.username,
      password: config.database.password,
      database: config.database.database,
      synchronize: false,
      logging: false
    });
    
    await dataSource.initialize();
    console.log('✅ Database connection established');
    
    // Check if soft delete columns exist
    console.log('📋 Checking if soft delete columns exist...');
    
    try {
      // Try to describe the leave_type table
      const columns = await dataSource.query(`
        SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'leave_type' 
        AND TABLE_SCHEMA = '${config.database.database}'
      `);
      
      const columnNames = columns.map(col => col.COLUMN_NAME);
      console.log('Found columns:', columnNames);
      
      const hasDeletedAt = columnNames.includes('deleted_at');
      const hasIsActive = columnNames.includes('is_active');
      
      if (hasDeletedAt && hasIsActive) {
        console.log('✅ Soft delete columns already exist');
        console.log('🎉 Migration is not needed');
        return;
      }
      
      console.log('❌ Soft delete columns missing');
      console.log('🚀 Running migration...\n');
      
      // Run migration
      if (!hasDeletedAt) {
        console.log('Adding deleted_at column...');
        await dataSource.query(`
          ALTER TABLE leave_type 
          ADD COLUMN deleted_at TIMESTAMP NULL
        `);
        console.log('✅ deleted_at column added');
      }
      
      if (!hasIsActive) {
        console.log('Adding is_active column...');
        await dataSource.query(`
          ALTER TABLE leave_type 
          ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE
        `);
        console.log('✅ is_active column added');
      }
      
      // Update existing records
      console.log('Updating existing records...');
      await dataSource.query(`
        UPDATE leave_type 
        SET is_active = TRUE, deleted_at = NULL
      `);
      console.log('✅ Existing records updated');
      
      // Add index for better performance
      console.log('Creating index...');
      try {
        await dataSource.query(`
          CREATE INDEX idx_leave_type_active 
          ON leave_type(is_active, deleted_at)
        `);
        console.log('✅ Index created');
      } catch (indexError) {
        console.log('⚠️  Index creation failed (might already exist):', indexError.message);
      }
      
      console.log('\n🎉 Migration completed successfully!');
      
    } catch (error) {
      console.error('❌ Error checking/running migration:', error);
      throw error;
    }
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    throw error;
  } finally {
    if (dataSource && dataSource.isInitialized) {
      await dataSource.destroy();
      console.log('\n🔌 Database connection closed');
    }
  }
}

// Run migration if called directly
if (require.main === module) {
  checkAndRunMigration()
    .then(() => {
      console.log('\n✅ Migration check completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ Migration check failed:', error);
      process.exit(1);
    });
}

module.exports = { checkAndRunMigration };
