/**
 * Diagnostic Script: Check Soft Delete Implementation
 * This script helps diagnose issues with the soft delete implementation
 */

const { DataSource } = require('typeorm');
const config = require('../config');

async function diagnoseSoftDelete() {
  let dataSource;
  
  try {
    console.log('🔍 Diagnosing Soft Delete Implementation...\n');
    
    // Create data source
    dataSource = new DataSource({
      type: config.database.type,
      host: config.database.host,
      port: config.database.port,
      username: config.database.username,
      password: config.database.password,
      database: config.database.database,
      synchronize: false,
      logging: false
    });
    
    await dataSource.initialize();
    console.log('✅ Database connection established');
    
    // Check table structure
    console.log('\n📋 Checking leave_type table structure...');
    try {
      const columns = await dataSource.query(`
        SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'leave_type' 
        AND TABLE_SCHEMA = '${config.database.database}'
        ORDER BY ORDINAL_POSITION
      `);
      
      console.log('Table columns:');
      columns.forEach(col => {
        console.log(`  - ${col.COLUMN_NAME}: ${col.DATA_TYPE} (nullable: ${col.IS_NULLABLE}, default: ${col.COLUMN_DEFAULT})`);
      });
      
      const hasDeletedAt = columns.some(col => col.COLUMN_NAME === 'deleted_at');
      const hasIsActive = columns.some(col => col.COLUMN_NAME === 'is_active');
      
      console.log(`\nSoft delete columns: deleted_at=${hasDeletedAt ? '✅' : '❌'}, is_active=${hasIsActive ? '✅' : '❌'}`);
      
    } catch (error) {
      console.error('❌ Error checking table structure:', error.message);
    }
    
    // Check data
    console.log('\n📊 Checking leave_type data...');
    try {
      const leaveTypes = await dataSource.query('SELECT * FROM leave_type LIMIT 5');
      console.log(`Found ${leaveTypes.length} leave types (showing first 5):`);
      leaveTypes.forEach((lt, index) => {
        console.log(`  ${index + 1}. ID: ${lt.id}, EN: ${lt.leave_type_en}, TH: ${lt.leave_type_th}`);
        if (lt.hasOwnProperty('deleted_at')) {
          console.log(`     deleted_at: ${lt.deleted_at}`);
        }
        if (lt.hasOwnProperty('is_active')) {
          console.log(`     is_active: ${lt.is_active}`);
        }
      });
      
    } catch (error) {
      console.error('❌ Error checking data:', error.message);
    }
    
    // Check indexes
    console.log('\n🔍 Checking indexes...');
    try {
      const indexes = await dataSource.query(`
        SELECT INDEX_NAME, COLUMN_NAME
        FROM INFORMATION_SCHEMA.STATISTICS 
        WHERE TABLE_NAME = 'leave_type' 
        AND TABLE_SCHEMA = '${config.database.database}'
      `);
      
      console.log('Table indexes:');
      indexes.forEach(idx => {
        console.log(`  - ${idx.INDEX_NAME}: ${idx.COLUMN_NAME}`);
      });
      
    } catch (error) {
      console.error('❌ Error checking indexes:', error.message);
    }
    
    // Test BaseController methods
    console.log('\n🧪 Testing BaseController methods...');
    try {
      const { BaseController } = require('../utils');
      const leaveTypeController = new BaseController('LeaveType');
      
      console.log('Testing findAll...');
      const allTypes = await leaveTypeController.findAll(dataSource);
      console.log(`findAll returned ${allTypes.length} types`);
      
      console.log('Testing findAllIncludingDeleted...');
      const allIncludingDeleted = await leaveTypeController.findAllIncludingDeleted(dataSource);
      console.log(`findAllIncludingDeleted returned ${allIncludingDeleted.length} types`);
      
      if (allTypes.length > 0) {
        console.log('Testing findOne...');
        const firstType = await leaveTypeController.findOne(dataSource, allTypes[0].id);
        console.log(`findOne returned: ${firstType ? 'Success' : 'Not found'}`);
      }
      
    } catch (error) {
      console.error('❌ Error testing BaseController:', error.message);
      console.error('Error stack:', error.stack);
    }
    
  } catch (error) {
    console.error('❌ Diagnosis failed:', error);
    throw error;
  } finally {
    if (dataSource && dataSource.isInitialized) {
      await dataSource.destroy();
      console.log('\n🔌 Database connection closed');
    }
  }
}

// Run diagnosis if called directly
if (require.main === module) {
  diagnoseSoftDelete()
    .then(() => {
      console.log('\n🎉 Diagnosis completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ Diagnosis failed:', error);
      process.exit(1);
    });
}

module.exports = { diagnoseSoftDelete };
