#!/usr/bin/env node

/**
 * Delete Orphaned User References Script
 * Run with: node scripts/delete-orphaned-user-references.js --confirm
 * 
 * This script deletes records in leave_used and leave_quota tables that reference
 * non-existent or deleted users. Use with caution and always backup first!
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function deleteOrphanedUserReferences() {
  try {
    console.log('🗑️ Orphaned User References Cleaner');
    console.log('====================================');
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('⚠️  WARNING: This will permanently delete orphaned user references!');
      console.log('   To confirm deletion, run: node scripts/delete-orphaned-user-references.js --confirm');
      console.log('   Always backup your database before running this script!');
      return;
    }
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const userRepo = AppDataSource.getRepository('User');
    const leaveUsedRepo = AppDataSource.getRepository('LeaveUsed');
    const leaveQuotaRepo = AppDataSource.getRepository('LeaveQuota');
    
    // Get all users
    const allUsers = await userRepo.find();
    console.log(`👥 Found ${allUsers.length} total users in database`);
    
    // Create set of valid user IDs for faster lookup
    const validUserIds = new Set(allUsers.map(user => user.id));
    
    // Find orphaned LeaveUsed records
    console.log('\n📊 Finding orphaned LeaveUsed records...');
    const allLeaveUsed = await leaveUsedRepo.find();
    const orphanedLeaveUsed = allLeaveUsed.filter(record => 
      record.userId && !validUserIds.has(record.userId)
    );
    
    console.log(`📋 Found ${orphanedLeaveUsed.length} orphaned LeaveUsed records`);
    
    // Find orphaned LeaveQuota records
    console.log('\n📊 Finding orphaned LeaveQuota records...');
    const allLeaveQuotas = await leaveQuotaRepo.find();
    const orphanedLeaveQuotas = allLeaveQuotas.filter(record => 
      record.userId && !validUserIds.has(record.userId)
    );
    
    console.log(`📋 Found ${orphanedLeaveQuotas.length} orphaned LeaveQuota records`);
    
    if (orphanedLeaveUsed.length === 0 && orphanedLeaveQuotas.length === 0) {
      console.log('\n✅ No orphaned user references found to delete!');
      return;
    }
    
    // Show what will be deleted
    console.log('\n🗑️ Records to be deleted:');
    console.log('=' .repeat(50));
    
    if (orphanedLeaveUsed.length > 0) {
      console.log(`\nLeaveUsed records (${orphanedLeaveUsed.length}):`);
      orphanedLeaveUsed.forEach((record, index) => {
        console.log(`  ${index + 1}. ID: ${record.id}, User ID: ${record.userId}, Used Days: ${record.usedDays}`);
      });
    }
    
    if (orphanedLeaveQuotas.length > 0) {
      console.log(`\nLeaveQuota records (${orphanedLeaveQuotas.length}):`);
      orphanedLeaveQuotas.forEach((record, index) => {
        console.log(`  ${index + 1}. ID: ${record.id}, User ID: ${record.userId}, Quota: ${record.quota}`);
      });
    }
    
    console.log('\n🚨 PROCEEDING WITH DELETION...');
    
    let deletedLeaveUsedCount = 0;
    let deletedLeaveQuotaCount = 0;
    let errorCount = 0;
    
    // Delete orphaned LeaveUsed records
    if (orphanedLeaveUsed.length > 0) {
      console.log('\n🗑️ Deleting orphaned LeaveUsed records...');
      
      for (const record of orphanedLeaveUsed) {
        try {
          await leaveUsedRepo.remove(record);
          console.log(`✅ Deleted LeaveUsed ID: ${record.id} (User ID: ${record.userId})`);
          deletedLeaveUsedCount++;
        } catch (error) {
          console.error(`❌ Error deleting LeaveUsed ID ${record.id}:`, error.message);
          errorCount++;
        }
      }
    }
    
    // Delete orphaned LeaveQuota records
    if (orphanedLeaveQuotas.length > 0) {
      console.log('\n🗑️ Deleting orphaned LeaveQuota records...');
      
      for (const record of orphanedLeaveQuotas) {
        try {
          await leaveQuotaRepo.remove(record);
          console.log(`✅ Deleted LeaveQuota ID: ${record.id} (User ID: ${record.userId})`);
          deletedLeaveQuotaCount++;
        } catch (error) {
          console.error(`❌ Error deleting LeaveQuota ID ${record.id}:`, error.message);
          errorCount++;
        }
      }
    }
    
    // Show deletion summary
    console.log('\n📊 Deletion Summary:');
    console.log('=' .repeat(30));
    console.log(`✅ Successfully deleted LeaveUsed records: ${deletedLeaveUsedCount}`);
    console.log(`✅ Successfully deleted LeaveQuota records: ${deletedLeaveQuotaCount}`);
    console.log(`❌ Errors: ${errorCount}`);
    console.log(`📁 Total records processed: ${orphanedLeaveUsed.length + orphanedLeaveQuotas.length}`);
    console.log(`🗑️ Total records deleted: ${deletedLeaveUsedCount + deletedLeaveQuotaCount}`);
    
    if (errorCount > 0) {
      console.log('\n⚠️ Some records could not be deleted. Check the error messages above.');
    } else {
      console.log('\n🎉 All orphaned user references have been successfully deleted!');
    }
    
  } catch (error) {
    console.error('❌ Cleanup failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the cleanup
if (require.main === module) {
  deleteOrphanedUserReferences();
}

module.exports = { deleteOrphanedUserReferences };
