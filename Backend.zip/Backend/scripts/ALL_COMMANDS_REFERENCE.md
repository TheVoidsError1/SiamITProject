# Complete Commands & Scripts Reference

This document provides a comprehensive guide to ALL commands, scripts, and utilities available in the SiamIT Leave Management System.

## 📋 **Overview**

This reference covers all available commands for database management, file cleanup, migrations, testing, and system maintenance.

## 🗂️ **Script Categories**

### 1. **File Cleanup & Orphaned Files Management**

#### Leave Request Attachments

**Check Orphaned Leave Request Files**
```bash
cd Backend
node scripts/check-orphaned-files.js
```
**Purpose**: Identifies leave request attachment files that are no longer referenced in the database.

**Delete Orphaned Leave Request Files**
```bash
cd Backend
node scripts/delete-orphaned-files.js --confirm
```
**Purpose**: Permanently deletes orphaned leave request attachment files.

#### Avatar Images

**Check Orphaned Avatar Files**
```bash
cd Backend
node scripts/check-orphaned-avatars.js
```
**Purpose**: Identifies avatar image files that are no longer referenced in the database.

**Delete Orphaned Avatar Files**
```bash
cd Backend
node scripts/delete-orphaned-avatars.js --confirm
```
**Purpose**: Permanently deletes orphaned avatar image files.

#### Announcement Images

**Check Orphaned Announcement Images**
```bash
cd Backend
node scripts/check-orphaned-announcements.js
```
**Purpose**: Identifies announcement image files that are no longer referenced in the database.

**Delete Orphaned Announcement Images**
```bash
cd Backend
node scripts/delete-orphaned-announcements.js --confirm
```
**Purpose**: Permanently deletes orphaned announcement image files.

### 2. **Database Management & Cleanup**

#### Leave Quota Management

**Check Orphaned Leave Quota Records**
```bash
cd Backend
node scripts/check-orphaned-leave-quota.js
```
**Purpose**: Identifies leave quota records that reference non-existent or deleted leave types.

**Delete Orphaned Leave Quota Records**
```bash
cd Backend
node scripts/delete-orphaned-leave-quota.js --confirm
```
**Purpose**: Permanently deletes leave quota records that reference invalid leave types.

#### Bulk Leave Request Operations

**Delete All Leave Requests (with files)**
```bash
cd Backend
node scripts/delete-all-leave-requests.js --confirm
```
**Purpose**: Permanently deletes ALL leave requests and their associated attachment files.
**⚠️ WARNING**: This will delete ALL leave requests in the database. Use with extreme caution.

**Backup Leave Requests**
```bash
cd Backend
node scripts/backup-leave-requests.js
```
**Purpose**: Creates a backup of all leave request data before bulk operations.

#### Leave Request Cleanup

**Cleanup Old Leave Requests**
```bash
cd Backend
node scripts/cleanupOldRecords.js
```
**Purpose**: Automatically removes leave request records older than 2 years.

**Manual Cleanup (via API)**
```bash
# Use the cleanup endpoint in your application
POST /api/super-admin/cleanup-old-leave-requests
```

### 3. **Database Migrations**

#### Soft Delete Migration

**Add Soft Delete to Leave Types**
```bash
cd Backend
node migrations/add-soft-delete-to-leave-type.js
```
**Purpose**: Adds soft delete functionality to leave types table.

**SQL Migration (Alternative)**
```bash
cd Backend
mysql -u username -p database_name < migrations/add-soft-delete-to-leave-type.sql
```

#### Request Quota Migration

**Rename Request Quota to Require End Date**
```bash
cd Backend
node migrations/rename-request-quota-to-require-enddate.js
```
**Purpose**: Updates database schema for leave request quota requirements.

**SQL Migration (Alternative)**
```bash
cd Backend
mysql -u username -p database_name < migrations/rename-request-quota-to-require-enddate.sql
```

#### Migration Management

**Check and Run Migrations**
```bash
cd Backend
node scripts/check-and-run-migration.js
```
**Purpose**: Automatically checks for pending migrations and runs them.

### 4. **Testing & Diagnostics**

#### Leave Type Testing

**Test Soft Delete Functionality**
```bash
cd Backend
node scripts/test-soft-delete.js
```
**Purpose**: Tests the soft delete functionality for leave types.

**Test Leave Type Cleanup**
```bash
cd Backend
node scripts/test-leave-type-cleanup.js
```
**Purpose**: Tests the leave type cleanup service.

**Diagnose Soft Delete Issues**
```bash
cd Backend
node scripts/diagnose-soft-delete.js
```
**Purpose**: Diagnoses issues with soft delete functionality.

#### Leave Type Usage Analysis

**Check Leave Type Usage**
```bash
cd Backend
node scripts/check-leave-type-usage.js
```
**Purpose**: Analyzes which leave types are being used and which can be safely deleted.

### 3. **Automated Daily Cleanup**

#### Scheduled Cleanup Jobs

**Daily Leave Type & Quota Cleanup (Automated)**
- **Schedule**: Every day at 2:00 AM (Asia/Bangkok timezone)
- **Purpose**: Automatically cleans up orphaned leave types and leave quota records
- **Process**:
  1. Cleans up orphaned soft-deleted leave types
  2. Automatically cleans up orphaned leave quota records that reference deleted/invalid leave types
- **Environment Variables**:
  - `ENABLE_LEAVE_TYPE_CLEANUP_CRON=true` (default: enabled)
  - `ENABLE_LEAVE_QUOTA_CLEANUP_CRON=true` (default: enabled)
  - `CRON_TZ=Asia/Bangkok` (default: Asia/Bangkok)

**Disable Automated Cleanup**
```bash
# Disable leave type cleanup
export ENABLE_LEAVE_TYPE_CLEANUP_CRON=false

# Disable leave quota cleanup
export ENABLE_LEAVE_QUOTA_CLEANUP_CRON=false

# Disable both
export ENABLE_LEAVE_TYPE_CLEANUP_CRON=false
export ENABLE_LEAVE_QUOTA_CLEANUP_CRON=false
```

### 4. **Data Seeding & Initialization**

#### Initial Data Setup

**Seed Initial Data**
```bash
cd Backend
node scripts/seed_initial_data.js
```
**Purpose**: Seeds the database with initial data (leave types, positions, departments, etc.).

### 5. **System Utilities**

#### Ngrok Tunnel

**Start Ngrok Tunnel**
```bash
cd Backend
node start-ngrok.js
```
**Purpose**: Starts ngrok tunnel for external access to the development server.

#### Batch Operations (Windows)

**Delete Leave Requests (Batch)**
```bash
cd Backend
scripts\delete-leave-requests.bat
```
**Purpose**: Windows batch file that runs backup and deletion scripts in sequence.

## 🔧 **Enhanced Hard Delete Functionality**

All deletion operations now use robust hard delete with the following features:

### **Primary Deletion Method**
- Uses `fs.unlinkSync()` to remove files
- Verifies file was actually deleted
- Logs success/failure for each file

### **Fallback Deletion Method**
- Uses `fs.rmSync(filePath, { force: true })` if primary method fails
- Handles stubborn files that can't be deleted normally
- Continues processing even if some files fail

### **Error Handling**
- Detailed logging of all operations
- Continues processing even if individual files fail
- Reports summary of successful vs failed deletions

## 📊 **Sample Outputs**

### Check Script Output
```
🔍 Orphaned Files Checker
========================
📊 Found 25 total users in database
🖼️  Found 18 users with avatars
📁 Found 15 unique avatar files referenced in database
📂 Found 22 files in avatars directory

🔍 Analysis Results:
==================
Total avatar files in uploads: 22
Referenced in database: 15
Orphaned avatars: 7

🗑️  Orphaned avatar files (can be safely deleted):
  1. avatar-1752466937504-135043751.gif (45.2 KB, modified: 1/15/2025)
  2. avatar-1752486829934-126334441.gif (32.1 KB, modified: 1/15/2025)
  ...

💡 To delete orphaned avatars, run:
node scripts/delete-orphaned-avatars.js --confirm
```

### Leave Quota Check Output
```
🔍 Orphaned Leave Quota Checker
===============================
✅ Database connection established
📊 Found 150 total leave quota records
✅ Found 8 valid (active) leave types
👥 Found 12 total positions

🔍 Analysis Results:
==================
Total leave quota records: 150
Valid records: 145
Orphaned leave type records: 5
Invalid position records: 0

🗑️ Orphaned leave quota records (can be safely deleted):
1. Leave Quota ID: abc123-def456-ghi789
   Position ID: pos-001
   Leave Type ID: type-deleted-001
   Leave Type: Annual Leave (ลาพักร้อน)
   Leave Type Status: Soft-deleted
   Deleted At: 2024-01-15T10:30:00.000Z
   Quota: 15
   --------------------------------------------------

📊 Summary of orphaned records:
Total records to remove: 5
Total quota to remove: 75

💡 To delete orphaned leave quota records, run:
node scripts/delete-orphaned-leave-quota.js --confirm
```

### Automated Daily Cleanup Output
```
🔄 Starting scheduled leave type cleanup...
✅ Leave type cleanup completed: {
  totalChecked: 3,
  deleted: 2,
  cannotDelete: 1,
  errors: 0
}
🗑️ Deleted leave types: [
  { id: 'type-001', name: 'Old Leave Type', reason: 'No usage found' }
]

🔄 Starting scheduled leave quota cleanup...
🔍 Found 5 orphaned leave quota records
🗑️ Deleting orphaned leave quota: quota-001 (Old Leave Type)
✅ Successfully deleted: quota-001
📊 Leave quota cleanup summary: {
  totalChecked: 5,
  deleted: 5,
  failed: 0,
  totalQuotaRemoved: 75
}
🗑️ Deleted leave quota records: [
  { id: 'quota-001', leaveType: 'Old Leave Type', quota: 15, status: 'Soft-deleted' }
]
✅ Scheduled cleanup process completed successfully!
```

### Migration Output
```
🔄 Running Migration: Add Soft Delete to Leave Type
==================================================
✅ Migration completed successfully
📊 Added columns: deleted_at, is_active
📊 Created index: idx_leave_type_active
```

### Cleanup Output
```
🗑️  Leave Request Cleanup
========================
📊 Found 1,250 leave request records
🗑️  Found 45 records older than 2 years
✅ Successfully deleted 45 old leave request records
💾 Space freed: 2.3 MB
```

## 🛡️ **Safety Features**

### **Confirmation Required**
- All deletion scripts require `--confirm` flag
- Prevents accidental deletion of files
- Shows preview before actual deletion

### **Backup Integration**
- Backup scripts available for critical operations
- Automatic backup before bulk deletions
- Restore capabilities for data recovery

### **Detailed Logging**
- Shows exactly what files will be deleted
- Reports file sizes and modification dates
- Calculates total space that will be freed

### **Error Recovery**
- Continues processing even if some files fail
- Reports detailed error messages
- Uses fallback deletion methods

## 🔄 **Recommended Workflows**

### **Regular Maintenance (Weekly)**
```bash
cd Backend

# 1. Check for orphaned files
node scripts/check-orphaned-avatars.js
node scripts/check-orphaned-announcements.js
node scripts/check-orphaned-files.js

# 2. Check for orphaned leave quota records
node scripts/check-orphaned-leave-quota.js

# 3. Check for orphaned user references
node scripts/check-orphaned-user-references.js

# 4. Create leave used records for users
node scripts/auto-create-leave-used.js

# 5. Clean up old records
node scripts/cleanupOldRecords.js

# 6. Check leave type usage
node scripts/check-leave-type-usage.js

# Note: Daily cleanup runs automatically at 2:00 AM
# - Leave type cleanup (ENABLE_LEAVE_TYPE_CLEANUP_CRON=true)
# - Leave quota cleanup (ENABLE_LEAVE_QUOTA_CLEANUP_CRON=true)
```

### **Monthly Deep Cleanup**
```bash
cd Backend

# 1. Backup critical data
node scripts/backup-leave-requests.js

# 2. Delete orphaned files
node scripts/delete-orphaned-avatars.js --confirm
node scripts/delete-orphaned-announcements.js --confirm
node scripts/delete-orphaned-files.js --confirm

# 3. Delete orphaned leave quota records
node scripts/delete-orphaned-leave-quota.js --confirm

# 4. Delete orphaned user references
node scripts/delete-orphaned-user-references.js --confirm

# 5. Test system functionality
node scripts/test-soft-delete.js
node scripts/diagnose-soft-delete.js

# Note: Daily automated cleanup handles most orphaned records automatically
```

### **Database Migration**
```bash
cd Backend

# 1. Check for pending migrations
node scripts/check-and-run-migration.js

# 2. Run specific migrations if needed
node migrations/add-soft-delete-to-leave-type.js
node migrations/rename-request-quota-to-require-enddate.js
```

### **Emergency Cleanup**
```bash
cd Backend

# 1. Create full backup
node scripts/backup-leave-requests.js

# 2. Use bulk deletion (EXTREME CAUTION)
node scripts/delete-all-leave-requests.js --confirm
```

## 📁 **File Locations**

### **Scripts Directory**
```
Backend/scripts/
├── check-orphaned-files.js
├── delete-orphaned-files.js
├── check-orphaned-avatars.js
├── delete-orphaned-avatars.js
├── check-orphaned-announcements.js
├── delete-orphaned-announcements.js
├── check-orphaned-leave-quota.js
├── delete-orphaned-leave-quota.js
├── delete-all-leave-requests.js
├── backup-leave-requests.js
├── cleanupOldRecords.js
├── check-and-run-migration.js
├── test-soft-delete.js
├── test-leave-type-cleanup.js
├── diagnose-soft-delete.js
├── check-leave-type-usage.js
├── seed_initial_data.js
└── delete-leave-requests.bat
```

### **Migrations Directory**
```
Backend/migrations/
├── add-soft-delete-to-leave-type.js
├── add-soft-delete-to-leave-type.sql
├── rename-request-quota-to-require-enddate.js
├── rename-request-quota-to-require-enddate.sql
└── README.md
```

### **Upload Directories**
```
Backend/uploads/
├── leave-uploads/          # Leave request attachments
├── avatars/               # User avatar images
└── announcements/         # Announcement images
```

## 🚨 **Important Notes**

### **Safety Guidelines**
1. **Always run check scripts first** to see what will be deleted
2. **Use `--confirm` flag** for all deletion operations
3. **Create backups** before running bulk deletion scripts
4. **Test on development** environment before production
5. **Monitor server logs** during deletion operations

### **Database Operations**
1. **Run migrations during maintenance windows**
2. **Test migrations on development first**
3. **Keep database backups before major changes**
4. **Monitor system performance after migrations**

### **File Management**
1. **Regular cleanup prevents storage issues**
2. **Orphaned files can accumulate over time**
3. **Use check scripts to identify issues**
4. **Clean up after bulk operations**

## 🔧 **Troubleshooting**

### **Common Issues**

#### Files Appear Gray in File Explorer
- **Cause**: Files are locked by the running server
- **Solution**: Stop the server, run cleanup scripts, then restart server

#### Permission Errors
- **Cause**: Node.js process lacks write permissions
- **Solution**: Run scripts with appropriate user permissions

#### Database Connection Errors
- **Cause**: Database configuration issues
- **Solution**: Verify database configuration in `Backend/config.js`

#### Migration Failures
- **Cause**: Database schema conflicts
- **Solution**: Check migration logs and resolve conflicts manually

### **Recovery Procedures**

#### Restore from Backup
```bash
# If you have database backups
mysql -u username -p database_name < backup_file.sql
```

#### Reset to Clean State
```bash
cd Backend
node scripts/seed_initial_data.js
```

#### Emergency Stop
- Stop all Node.js processes
- Check system logs for errors
- Restart services one by one

## 📞 **Support & Maintenance**

### **Regular Tasks**
- **Daily**: Automated cleanup runs at 2:00 AM (leave types + leave quota)
- **Weekly**: Run orphaned file checks
- **Monthly**: Perform deep cleanup
- **Quarterly**: Review and update scripts
- **Annually**: Archive old data and optimize database

### **Monitoring**
- Monitor disk space usage
- Check database performance
- Review error logs regularly
- Update scripts as needed

This comprehensive reference covers all available commands and scripts in the SiamIT Leave Management System. Use it as your go-to guide for system maintenance and operations.
