#!/usr/bin/env node

/**
 * Script to backup all leave requests to a JSON file
 * 
 * This script exports all leave requests to a JSON file for backup purposes.
 * 
 * Usage: node scripts/backup-leave-requests.js [output-file]
 */

require('reflect-metadata');
const { DataSource } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const leaveRequestEntity = require('../EnityTable/leaveRequest.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [leaveRequestEntity],
});

async function backupLeaveRequests(outputFile = null) {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    
    // Get all leave requests
    console.log('📊 Fetching all leave requests...');
    const leaveRequests = await leaveRequestRepo.find({
      order: { createdAt: 'DESC' }
    });

    console.log(`📋 Found ${leaveRequests.length} leave requests`);

    if (leaveRequests.length === 0) {
      console.log('ℹ️  No leave requests found to backup.');
      return;
    }

    // Generate output filename if not provided
    if (!outputFile) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      outputFile = `leave-requests-backup-${timestamp}.json`;
    }

    // Ensure output directory exists
    const outputDir = path.join(__dirname, '..', 'backups');
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const fullOutputPath = path.join(outputDir, outputFile);

    // Create backup data with metadata
    const backupData = {
      metadata: {
        exportDate: new Date().toISOString(),
        totalRecords: leaveRequests.length,
        database: config.database.database,
        version: '1.0'
      },
      leaveRequests: leaveRequests
    };

    // Write to file
    fs.writeFileSync(fullOutputPath, JSON.stringify(backupData, null, 2), 'utf8');

    console.log(`✅ Backup completed successfully!`);
    console.log(`📁 File saved to: ${fullOutputPath}`);
    console.log(`📊 Total records backed up: ${leaveRequests.length}`);

    // Show summary
    const statusCounts = {};
    leaveRequests.forEach(request => {
      const status = request.status || 'unknown';
      statusCounts[status] = (statusCounts[status] || 0) + 1;
    });

    console.log('\n📈 Status summary:');
    Object.entries(statusCounts).forEach(([status, count]) => {
      console.log(`  ${status}: ${count} requests`);
    });

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  const outputFile = process.argv[2];
  
  console.log('🚀 Leave Request Backup Script');
  console.log('==============================');
  backupLeaveRequests(outputFile)
    .then(() => {
      console.log('✨ Backup script completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Backup script failed:', error.message);
      process.exit(1);
    });
}

module.exports = { backupLeaveRequests };
