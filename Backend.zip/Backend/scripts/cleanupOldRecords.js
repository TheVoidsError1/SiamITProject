const { DataSource } = require('typeorm');
const { LessThan } = require('typeorm');
const path = require('path');

// Import entities
const userEntity = require('../EnityTable/User.entity.js');
const departmentEntity = require('../EnityTable/department.js');
const positionEntity = require('../EnityTable/position.js');
const leaveTypeEntity = require('../EnityTable/leaveType.js');
const leaveQuotaEntity = require('../EnityTable/leaveQuota.js');
const leaveRequestEntity = require('../EnityTable/leaveRequest.entity.js');
const leaveUsedEntity = require('../EnityTable/leaveUsed.js');
const announcementsEntity = require('../EnityTable/announcements.js');
const customHolidayEntity = require('../EnityTable/customHoliday.js');

// Database configuration
const AppDataSource = new DataSource({
  type: 'mysql',
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  username: process.env.DB_USERNAME || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_DATABASE || 'siamit_leave_management',
  synchronize: false,
  logging: false,
  entities: [
    userEntity,
    departmentEntity,
    positionEntity,
    leaveTypeEntity,
    leaveQuotaEntity,
    leaveRequestEntity,
    leaveUsedEntity,
    announcementsEntity,
    customHolidayEntity
  ]
});

/**
 * Clean up leave requests older than 2 years
 */
async function cleanupOldLeaveRequests() {
  try {
    console.log('Starting cleanup of old leave request records...');
    
    // Calculate date 2 years ago
    const twoYearsAgo = new Date();
    twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
    
    console.log(`Cleaning up leave requests older than: ${twoYearsAgo.toISOString()}`);
    
    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    
    // Find all records older than 2 years
    const oldRecords = await leaveRequestRepo.find({
      where: {
        createdAt: LessThan(twoYearsAgo)
      }
    });
    
    console.log(`Found ${oldRecords.length} records to delete`);
    
    if (oldRecords.length === 0) {
      console.log('No old records found to delete');
      return {
        success: true,
        message: 'No old records found to delete',
        deletedCount: 0
      };
    }
    
    // Delete the old records
    const result = await leaveRequestRepo.delete({
      createdAt: LessThan(twoYearsAgo)
    });
    
    console.log(`Successfully deleted ${result.affected} old leave request records`);
    
    return {
      success: true,
      message: `Successfully deleted ${result.affected} old leave request records`,
      deletedCount: result.affected
    };
    
  } catch (error) {
    console.error('Error cleaning up old leave requests:', error);
    return {
      success: false,
      message: `Error: ${error.message}`,
      deletedCount: 0
    };
  }
}

/**
 * Main function to run the cleanup
 */
async function main() {
  try {
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('Database connection established');
    
    // Run cleanup
    const result = await cleanupOldLeaveRequests();
    
    if (result.success) {
      console.log('✅ Cleanup completed successfully:', result.message);
    } else {
      console.error('❌ Cleanup failed:', result.message);
      process.exit(1);
    }
    
  } catch (error) {
    console.error('❌ Error during cleanup process:', error);
    process.exit(1);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('Database connection closed');
    }
  }
}

// Run the script if called directly
if (require.main === module) {
  main();
}

module.exports = {
  cleanupOldLeaveRequests,
  main
};
