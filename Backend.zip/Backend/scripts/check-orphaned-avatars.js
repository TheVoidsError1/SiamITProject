#!/usr/bin/env node

/**
 * Script to check for orphaned avatar files
 * These are files that exist in the uploads/avatars folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource, Not } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const userEntity = require('../EnityTable/User.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [userEntity],
});

async function checkOrphanedAvatars() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const userRepo = AppDataSource.getRepository('User');
    const avatarsUploadPath = config.getAvatarsUploadPath();
    
    // Get all users with avatar URLs
    const users = await userRepo.find();
    
    console.log(`📊 Found ${users.length} total users in database`);
    
    // Collect all referenced avatar file names
    const referencedAvatars = new Set();
    let usersWithAvatars = 0;
    
    users.forEach(user => {
      if (user.avatar_url && user.avatar_url.trim() !== '') {
        const fileName = path.basename(user.avatar_url);
        referencedAvatars.add(fileName);
        usersWithAvatars++;
      }
    });
    
    console.log(`🖼️  Found ${usersWithAvatars} users with avatars`);
    console.log(`📁 Found ${referencedAvatars.size} unique avatar files referenced in database`);
    
    // Get all files in avatars uploads directory
    const uploadFiles = fs.readdirSync(avatarsUploadPath);
    console.log(`📂 Found ${uploadFiles.length} files in avatars directory`);
    
    // Find orphaned avatar files
    const orphanedAvatars = uploadFiles.filter(file => !referencedAvatars.has(file));
    
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total avatar files in uploads: ${uploadFiles.length}`);
    console.log(`Referenced in database: ${referencedAvatars.size}`);
    console.log(`Orphaned avatars: ${orphanedAvatars.length}`);
    
    // Debug: Show referenced files
    if (referencedAvatars.size > 0) {
      console.log('\n📋 Referenced avatar files in database:');
      Array.from(referencedAvatars).forEach((file, index) => {
        console.log(`  ${index + 1}. ${file}`);
      });
    }
    
    // Debug: Show all files in directory
    console.log('\n📂 All files in avatars directory:');
    uploadFiles.forEach((file, index) => {
      const isReferenced = referencedAvatars.has(file);
      const status = isReferenced ? '✅ REFERENCED' : '❌ ORPHANED';
      console.log(`  ${index + 1}. ${file} - ${status}`);
    });
    
    if (orphanedAvatars.length > 0) {
      console.log('\n🗑️  Orphaned avatar files (can be safely deleted):');
      orphanedAvatars.forEach((file, index) => {
        const filePath = path.join(avatarsUploadPath, file);
        const stats = fs.statSync(filePath);
        const fileSize = (stats.size / 1024).toFixed(2); // Size in KB
        const modifiedDate = stats.mtime.toLocaleDateString();
        console.log(`  ${index + 1}. ${file} (${fileSize} KB, modified: ${modifiedDate})`);
      });
      
      console.log('\n💡 To delete orphaned avatars, run:');
      console.log('node scripts/delete-orphaned-avatars.js --confirm');
    } else {
      console.log('\n✅ No orphaned avatar files found. All files are properly referenced.');
    }

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🔍 Orphaned Avatars Checker');
  console.log('===========================');
  checkOrphanedAvatars()
    .then(() => {
      console.log('✨ Check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Check failed:', error.message);
      process.exit(1);
    });
}

module.exports = { checkOrphanedAvatars };
