/**
 * Test Script: Verify Soft Delete Functionality
 * This script tests the soft delete implementation for leave types
 */

const { DataSource } = require('typeorm');
const config = require('../config');
const { BaseController } = require('../utils');

async function testSoftDelete() {
  let dataSource;
  
  try {
    console.log('🧪 Testing Soft Delete Functionality...\n');
    
    // Create data source
    dataSource = new DataSource({
      type: config.database.type,
      host: config.database.host,
      port: config.database.port,
      username: config.database.username,
      password: config.database.password,
      database: config.database.database,
      synchronize: false,
      logging: false
    });
    
    await dataSource.initialize();
    console.log('✅ Database connection established');
    
    // Create LeaveType controller instance
    const leaveTypeController = new BaseController('LeaveType');
    
    // Test 1: Get all active leave types
    console.log('\n📋 Test 1: Get all active leave types');
    const activeTypes = await leaveTypeController.findAll(dataSource);
    console.log(`Found ${activeTypes.length} active leave types:`, 
      activeTypes.map(lt => lt.leave_type_en));
    
    // Test 2: Get all types including deleted
    console.log('\n📋 Test 2: Get all types including deleted');
    const allTypes = await leaveTypeController.findAllIncludingDeleted(dataSource);
    console.log(`Found ${allTypes.length} total leave types`);
    
    // Test 3: Soft delete a leave type (if any exist)
    if (activeTypes.length > 0) {
      const testType = activeTypes[0];
      console.log(`\n📋 Test 3: Soft delete "${testType.leave_type_en}"`);
      
      await leaveTypeController.softDelete(dataSource, testType.id);
      console.log('✅ Soft delete completed');
      
      // Verify it's no longer in active list
      const activeAfterDelete = await leaveTypeController.findAll(dataSource);
      console.log(`Active types after delete: ${activeAfterDelete.length}`);
      
      // Verify it's still in all list
      const allAfterDelete = await leaveTypeController.findAllIncludingDeleted(dataSource);
      const deletedType = allAfterDelete.find(lt => lt.id === testType.id);
      console.log(`Deleted type found: ${deletedType ? 'Yes' : 'No'}`);
      console.log(`Deleted at: ${deletedType?.deleted_at}`);
      
      // Test 4: Restore the deleted type
      console.log('\n📋 Test 4: Restore deleted type');
      await leaveTypeController.restore(dataSource, testType.id);
      console.log('✅ Restore completed');
      
      // Verify it's back in active list
      const activeAfterRestore = await leaveTypeController.findAll(dataSource);
      console.log(`Active types after restore: ${activeAfterRestore.length}`);
    } else {
      console.log('\n⚠️  No leave types found to test with');
    }
    
    console.log('\n🎉 All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    throw error;
  } finally {
    if (dataSource && dataSource.isInitialized) {
      await dataSource.destroy();
      console.log('\n🔌 Database connection closed');
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  testSoftDelete()
    .then(() => {
      console.log('\n✅ All tests passed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n❌ Tests failed:', error);
      process.exit(1);
    });
}

module.exports = { testSoftDelete };
