#!/usr/bin/env node

/**
 * Create Leave Used Records for User Script
 * Run with: node scripts/create-leave-used-for-user.js [userId] [year]
 * 
 * This script creates leave used records for a specific user and year.
 * If no userId is provided, it will use the first user found in the database.
 * If no year is provided, it will use the current year.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leave_use.js'),
    require('../EnityTable/leaveType.js')
  ],
});

async function createLeaveUsedForUser() {
  try {
    console.log('🚀 Leave Used Records Creator');
    console.log('=============================');
    
    // Get command line arguments
    const args = process.argv.slice(2);
    const targetUserId = args[0];
    const targetYear = args[1] || new Date().getFullYear();
    
    console.log(`📅 Target year: ${targetYear}`);
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const userRepo = AppDataSource.getRepository('User');
    const leaveUsedRepo = AppDataSource.getRepository('LeaveUsed');
    const leaveTypeRepo = AppDataSource.getRepository('LeaveType');
    
    // Find target user
    let targetUser;
    if (targetUserId) {
      targetUser = await userRepo.findOne({ where: { id: targetUserId } });
      if (!targetUser) {
        console.error(`❌ User with ID ${targetUserId} not found!`);
        return;
      }
    } else {
      // Get the first user if no ID provided
      const users = await userRepo.find();
      if (users.length === 0) {
        console.error('❌ No users found in database!');
        return;
      }
      targetUser = users[0];
    }
    
    console.log(`👤 Target user: ${targetUser.name} (ID: ${targetUser.id})`);
    
    // Get all active leave types
    const leaveTypes = await leaveTypeRepo.find({
      where: {
        deleted_at: null,
        is_active: true
      }
    });
    
    console.log(`📋 Found ${leaveTypes.length} active leave types`);
    
    if (leaveTypes.length === 0) {
      console.error('❌ No active leave types found!');
      return;
    }
    
    // Check existing leave used records for this user and year
    const existingRecords = await leaveUsedRepo.find({
      where: {
        user_id: targetUser.id
      }
    });
    
    console.log(`📊 Found ${existingRecords.length} existing leave used records for this user`);
    
    // Filter out records that already exist for the target year
    const existingLeaveTypeIds = new Set();
    existingRecords.forEach(record => {
      // Check if record is for the target year (you might need to adjust this logic based on your data structure)
      existingLeaveTypeIds.add(record.leave_type_id);
    });
    
    // Create leave used records for each leave type
    const recordsToCreate = [];
    const recordsCreated = [];
    const recordsSkipped = [];
    
    for (const leaveType of leaveTypes) {
      if (existingLeaveTypeIds.has(leaveType.id)) {
        console.log(`⏭️  Skipping ${leaveType.leave_type_en} (${leaveType.leave_type_th}) - record already exists`);
        recordsSkipped.push(leaveType);
        continue;
      }
      
      const leaveUsedRecord = {
        user_id: targetUser.id,
        leave_type_id: leaveType.id,
        days: 0,
        hour: 0,
        created_at: new Date(),
        updated_at: new Date()
      };
      
      recordsToCreate.push(leaveUsedRecord);
      console.log(`➕ Will create record for ${leaveType.leave_type_en} (${leaveType.leave_type_th})`);
    }
    
    if (recordsToCreate.length === 0) {
      console.log('\n✅ All leave used records already exist for this user!');
      return;
    }
    
    // Show what will be created
    console.log('\n📋 Records to be created:');
    console.log('=' .repeat(50));
    recordsToCreate.forEach((record, index) => {
      const leaveType = leaveTypes.find(lt => lt.id === record.leave_type_id);
      console.log(`${index + 1}. User: ${targetUser.name}`);
      console.log(`   Leave Type: ${leaveType.leave_type_en} (${leaveType.leave_type_th})`);
      console.log(`   Days: ${record.days}`);
      console.log(`   Hours: ${record.hour}`);
      console.log('   ' + '-'.repeat(30));
    });
    
    // Ask for confirmation
    console.log('\n⚠️  This will create new leave used records.');
    console.log('   To confirm creation, run: node scripts/create-leave-used-for-user.js --confirm');
    
    // Check for confirmation flag
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('\n💡 To actually create the records, run:');
      console.log(`   node scripts/create-leave-used-for-user.js ${targetUser.id} ${targetYear} --confirm`);
      return;
    }
    
    console.log('\n🚀 PROCEEDING WITH CREATION...');
    
    // Create the records
    let createdCount = 0;
    let errorCount = 0;
    
    for (const record of recordsToCreate) {
      try {
        const savedRecord = await leaveUsedRepo.save(record);
        const leaveType = leaveTypes.find(lt => lt.id === record.leave_type_id);
        console.log(`✅ Created record for ${leaveType.leave_type_en} (ID: ${savedRecord.id})`);
        recordsCreated.push(savedRecord);
        createdCount++;
      } catch (error) {
        console.error(`❌ Error creating record for leave type ${record.leave_type_id}:`, error.message);
        errorCount++;
      }
    }
    
    // Show creation summary
    console.log('\n📊 Creation Summary:');
    console.log('=' .repeat(30));
    console.log(`✅ Successfully created: ${createdCount} records`);
    console.log(`❌ Errors: ${errorCount} records`);
    console.log(`⏭️  Skipped (already exist): ${recordsSkipped.length} records`);
    console.log(`📁 Total leave types: ${leaveTypes.length}`);
    
    if (errorCount > 0) {
      console.log('\n⚠️ Some records could not be created. Check the error messages above.');
    } else {
      console.log('\n🎉 All leave used records have been successfully created!');
    }
    
    // Show final status
    console.log('\n📋 Final Status:');
    console.log('=' .repeat(20));
    console.log(`User: ${targetUser.name} (${targetUser.id})`);
    console.log(`Year: ${targetYear}`);
    console.log(`Total leave used records: ${existingRecords.length + createdCount}`);
    
  } catch (error) {
    console.error('❌ Creation failed:', error);
    console.error('Error details:', error.message);
    if (error.stack) {
      console.error('Stack trace:', error.stack);
    }
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the creation
if (require.main === module) {
  createLeaveUsedForUser();
}

module.exports = { createLeaveUsedForUser };
