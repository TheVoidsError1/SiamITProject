#!/usr/bin/env node

/**
 * Script to delete orphaned avatar files
 * These are files that exist in the uploads/avatars folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource, Not } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const userEntity = require('../EnityTable/User.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [userEntity],
});

async function deleteOrphanedAvatars() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const userRepo = AppDataSource.getRepository('User');
    const avatarsUploadPath = config.getAvatarsUploadPath();
    
    // Get all users
    const users = await userRepo.find();
    
    console.log(`📊 Found ${users.length} total users in database`);
    
    // Collect all referenced avatar file names
    const referencedAvatars = new Set();
    let usersWithAvatars = 0;
    
    users.forEach(user => {
      if (user.avatar_url && user.avatar_url.trim() !== '') {
        const fileName = path.basename(user.avatar_url);
        referencedAvatars.add(fileName);
        usersWithAvatars++;
      }
    });
    
    console.log(`🖼️  Found ${usersWithAvatars} users with avatars`);
    console.log(`📁 Found ${referencedAvatars.size} unique avatar files referenced in database`);
    
    // Get all files in avatars uploads directory
    const uploadFiles = fs.readdirSync(avatarsUploadPath);
    console.log(`📂 Found ${uploadFiles.length} files in avatars directory`);
    
    // Find orphaned avatar files
    const orphanedAvatars = uploadFiles.filter(file => !referencedAvatars.has(file));
    
    console.log(`\n🗑️  Found ${orphanedAvatars.length} orphaned avatar files`);
    
    if (orphanedAvatars.length === 0) {
      console.log('✅ No orphaned avatar files to delete.');
      return;
    }
    
    // Show orphaned avatars with details
    console.log('\nFiles to be deleted:');
    let totalSize = 0;
    orphanedAvatars.forEach((file, index) => {
      const filePath = path.join(avatarsUploadPath, file);
      const stats = fs.statSync(filePath);
      const fileSize = stats.size;
      totalSize += fileSize;
      const fileSizeKB = (fileSize / 1024).toFixed(2);
      const modifiedDate = stats.mtime.toLocaleDateString();
      console.log(`  ${index + 1}. ${file} (${fileSizeKB} KB, modified: ${modifiedDate})`);
    });
    
    const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    console.log(`\n📊 Total size to be freed: ${totalSizeMB} MB`);
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('\n⚠️  WARNING: This will permanently delete orphaned avatar files!');
      console.log('   To confirm deletion, run: node scripts/delete-orphaned-avatars.js --confirm');
      return;
    }
    
    console.log('\n🗑️  Proceeding with HARD DELETE...');
    
    let deletedCount = 0;
    let errorCount = 0;
    let freedSpace = 0;
    
    for (const file of orphanedAvatars) {
      try {
        const filePath = path.join(avatarsUploadPath, file);
        const stats = fs.statSync(filePath);
        const fileSize = stats.size;
        
        if (fs.existsSync(filePath)) {
          // Force delete the avatar file (hard delete)
          fs.unlinkSync(filePath);
          
          // Verify file is actually deleted
          if (!fs.existsSync(filePath)) {
            console.log(`✅ HARD DELETED: ${file}`);
            deletedCount++;
            freedSpace += fileSize;
          } else {
            console.error(`❌ FAILED to delete: ${file} - file still exists`);
            
            // Try alternative deletion method
            try {
              fs.rmSync(filePath, { force: true });
              if (!fs.existsSync(filePath)) {
                console.log(`✅ Force deleted: ${file}`);
                deletedCount++;
                freedSpace += fileSize;
              } else {
                console.error(`❌ Force delete also failed for: ${file}`);
                errorCount++;
              }
            } catch (forceDeleteError) {
              console.error(`❌ Force delete failed for ${file}:`, forceDeleteError.message);
              errorCount++;
            }
          }
        } else {
          console.log(`⚠️  File not found (already deleted?): ${file}`);
        }
      } catch (error) {
        console.error(`❌ Error deleting ${file}:`, error.message);
        errorCount++;
      }
    }
    
    const freedSpaceMB = (freedSpace / (1024 * 1024)).toFixed(2);
    
    console.log('\n📊 Deletion Summary:');
    console.log(`✅ Successfully deleted: ${deletedCount} avatar files`);
    console.log(`❌ Errors: ${errorCount} files`);
    console.log(`📁 Total orphaned avatars: ${orphanedAvatars.length}`);
    console.log(`💾 Space freed: ${freedSpaceMB} MB`);

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🗑️  Orphaned Avatars Cleanup');
  console.log('============================');
  deleteOrphanedAvatars()
    .then(() => {
      console.log('✨ Cleanup completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Cleanup failed:', error.message);
      process.exit(1);
    });
}

module.exports = { deleteOrphanedAvatars };
