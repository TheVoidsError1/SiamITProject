#!/usr/bin/env node

/**
 * Check Orphaned User References Script
 * Run with: node scripts/check-orphaned-user-references.js
 * 
 * This script identifies records in leave_used and leave_quota tables that reference
 * non-existent or deleted users. These orphaned records can be safely removed to maintain data integrity.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function checkOrphanedUserReferences() {
  try {
    console.log('🔍 Orphaned User References Checker');
    console.log('====================================');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const userRepo = AppDataSource.getRepository('User');
    const leaveUsedRepo = AppDataSource.getRepository('LeaveUsed');
    const leaveQuotaRepo = AppDataSource.getRepository('LeaveQuota');
    
    // Get all users
    const allUsers = await userRepo.find();
    console.log(`👥 Found ${allUsers.length} total users in database`);
    
    // Create set of valid user IDs for faster lookup
    const validUserIds = new Set(allUsers.map(user => user.id));
    
    // Check LeaveUsed table
    console.log('\n📊 Checking LeaveUsed table...');
    const allLeaveUsed = await leaveUsedRepo.find();
    console.log(`📋 Found ${allLeaveUsed.length} total leave used records`);
    
    const orphanedLeaveUsed = [];
    const validLeaveUsed = [];
    
    for (const leaveUsed of allLeaveUsed) {
      if (leaveUsed.userId && !validUserIds.has(leaveUsed.userId)) {
        orphanedLeaveUsed.push({
          ...leaveUsed,
          userStatus: 'User Not Found'
        });
      } else {
        validLeaveUsed.push(leaveUsed);
      }
    }
    
    // Check LeaveQuota table
    console.log('\n📊 Checking LeaveQuota table...');
    const allLeaveQuotas = await leaveQuotaRepo.find();
    console.log(`📋 Found ${allLeaveQuotas.length} total leave quota records`);
    
    const orphanedLeaveQuotas = [];
    const validLeaveQuotas = [];
    
    for (const quota of allLeaveQuotas) {
      if (quota.userId && !validUserIds.has(quota.userId)) {
        orphanedLeaveQuotas.push({
          ...quota,
          userStatus: 'User Not Found'
        });
      } else {
        validLeaveQuotas.push(quota);
      }
    }
    
    // Display analysis results
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total users in database: ${allUsers.length}`);
    console.log(`Total leave used records: ${allLeaveUsed.length}`);
    console.log(`Valid leave used records: ${validLeaveUsed.length}`);
    console.log(`Orphaned leave used records: ${orphanedLeaveUsed.length}`);
    console.log(`Total leave quota records: ${allLeaveQuotas.length}`);
    console.log(`Valid leave quota records: ${validLeaveQuotas.length}`);
    console.log(`Orphaned leave quota records: ${orphanedLeaveQuotas.length}`);
    
    // Show orphaned LeaveUsed records
    if (orphanedLeaveUsed.length > 0) {
      console.log('\n🗑️ Orphaned LeaveUsed records (can be safely deleted):');
      console.log('=' .repeat(80));
      
      orphanedLeaveUsed.forEach((record, index) => {
        console.log(`${index + 1}. LeaveUsed ID: ${record.id}`);
        console.log(`   User ID: ${record.userId} (${record.userStatus})`);
        console.log(`   Leave Type ID: ${record.leaveTypeId}`);
        console.log(`   Year: ${record.year}`);
        console.log(`   Used Days: ${record.usedDays}`);
        console.log(`   Created At: ${record.createdAt}`);
        console.log('   ' + '-'.repeat(50));
      });
      
      // Calculate total used days that would be freed
      const totalUsedDaysToRemove = orphanedLeaveUsed.reduce((sum, record) => sum + (record.usedDays || 0), 0);
      console.log(`\n📊 Summary of orphaned LeaveUsed records:`);
      console.log(`Total records to remove: ${orphanedLeaveUsed.length}`);
      console.log(`Total used days to remove: ${totalUsedDaysToRemove}`);
    } else {
      console.log('\n✅ No orphaned LeaveUsed records found!');
    }
    
    // Show orphaned LeaveQuota records
    if (orphanedLeaveQuotas.length > 0) {
      console.log('\n🗑️ Orphaned LeaveQuota records (can be safely deleted):');
      console.log('=' .repeat(80));
      
      orphanedLeaveQuotas.forEach((record, index) => {
        console.log(`${index + 1}. LeaveQuota ID: ${record.id}`);
        console.log(`   User ID: ${record.userId} (${record.userStatus})`);
        console.log(`   Leave Type ID: ${record.leaveTypeId}`);
        console.log(`   Position ID: ${record.positionId}`);
        console.log(`   Year: ${record.year}`);
        console.log(`   Quota: ${record.quota}`);
        console.log(`   Created At: ${record.createdAt}`);
        console.log('   ' + '-'.repeat(50));
      });
      
      // Calculate total quota that would be freed
      const totalQuotaToRemove = orphanedLeaveQuotas.reduce((sum, record) => sum + (record.quota || 0), 0);
      console.log(`\n📊 Summary of orphaned LeaveQuota records:`);
      console.log(`Total records to remove: ${orphanedLeaveQuotas.length}`);
      console.log(`Total quota to remove: ${totalQuotaToRemove}`);
    } else {
      console.log('\n✅ No orphaned LeaveQuota records found!');
    }
    
    // Show breakdown by user ID
    if (orphanedLeaveUsed.length > 0 || orphanedLeaveQuotas.length > 0) {
      const orphanedUserIds = new Set();
      orphanedLeaveUsed.forEach(record => orphanedUserIds.add(record.userId));
      orphanedLeaveQuotas.forEach(record => orphanedUserIds.add(record.userId));
      
      console.log('\n📈 Breakdown by orphaned user IDs:');
      console.log('=' .repeat(50));
      console.log(`Total unique orphaned user IDs: ${orphanedUserIds.size}`);
      
      Array.from(orphanedUserIds).forEach((userId, index) => {
        const leaveUsedCount = orphanedLeaveUsed.filter(r => r.userId === userId).length;
        const leaveQuotaCount = orphanedLeaveQuotas.filter(r => r.userId === userId).length;
        console.log(`${index + 1}. User ID: ${userId}`);
        console.log(`   LeaveUsed records: ${leaveUsedCount}`);
        console.log(`   LeaveQuota records: ${leaveQuotaCount}`);
        console.log(`   Total records: ${leaveUsedCount + leaveQuotaCount}`);
        console.log('   ' + '-'.repeat(30));
      });
    }
    
    // Show cleanup recommendations
    if (orphanedLeaveUsed.length > 0 || orphanedLeaveQuotas.length > 0) {
      console.log('\n💡 Cleanup Recommendations:');
      console.log('=' .repeat(40));
      console.log('1. Review the orphaned records above');
      console.log('2. Verify that the referenced users are truly deleted');
      console.log('3. If confirmed safe, run the cleanup script:');
      console.log('   node scripts/delete-orphaned-user-references.js --confirm');
      console.log('4. Always backup your database before running cleanup scripts');
    }
    
    console.log('\n✅ Orphaned user references check completed successfully!');
    
  } catch (error) {
    console.error('❌ Check failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the check
if (require.main === module) {
  checkOrphanedUserReferences();
}

module.exports = { checkOrphanedUserReferences };
