#!/usr/bin/env node

/**
 * Delete Orphaned Leave Used Records Script
 * Run with: node scripts/delete-orphaned-leave-used.js --confirm
 * 
 * This script deletes records in leave_used table that reference
 * non-existent or deleted users.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function deleteOrphanedLeaveUsed() {
  try {
    console.log('🗑️ Orphaned Leave Used Records Cleaner');
    console.log('=======================================');
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('⚠️  WARNING: This will permanently delete orphaned leave used records!');
      console.log('   To confirm deletion, run: node scripts/delete-orphaned-leave-used.js --confirm');
      console.log('   Always backup your database before running this script!');
      return;
    }
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const userRepo = AppDataSource.getRepository('User');
    const leaveUsedRepo = AppDataSource.getRepository('LeaveUsed');
    
    // Get all users
    const allUsers = await userRepo.find();
    console.log(`👥 Found ${allUsers.length} total users in database`);
    
    // Create set of valid user IDs for faster lookup
    const validUserIds = new Set(allUsers.map(user => user.id));
    
    // Find orphaned records
    console.log('\n📊 Finding orphaned leave used records...');
    const allLeaveUsed = await leaveUsedRepo.find();
    const orphanedRecords = allLeaveUsed.filter(record => 
      record.user_id && !validUserIds.has(record.user_id)
    );
    
    console.log(`📋 Found ${orphanedRecords.length} orphaned leave used records`);
    
    if (orphanedRecords.length === 0) {
      console.log('\n✅ No orphaned leave used records found to delete!');
      return;
    }
    
    // Show what will be deleted
    console.log('\n🗑️ Records to be deleted:');
    console.log('=' .repeat(50));
    
    orphanedRecords.forEach((record, index) => {
      console.log(`${index + 1}. ID: ${record.id}`);
      console.log(`   User ID: ${record.user_id} (not found in User table)`);
      console.log(`   Leave Type ID: ${record.leave_type_id}`);
      console.log(`   Days: ${record.days}`);
      console.log(`   Hour: ${record.hour}`);
      console.log(`   Created At: ${record.created_at}`);
      console.log('   ' + '-'.repeat(30));
    });
    
    console.log('\n🚨 PROCEEDING WITH DELETION...');
    
    let deletedCount = 0;
    let errorCount = 0;
    let totalUsedDays = 0;
    
    // Delete orphaned records
    for (const record of orphanedRecords) {
      try {
        await leaveUsedRepo.remove(record);
        console.log(`✅ Deleted record ID: ${record.id} (User ID: ${record.user_id}, Days: ${record.days})`);
        deletedCount++;
        totalUsedDays += record.days || 0;
      } catch (error) {
        console.error(`❌ Error deleting record ID ${record.id}:`, error.message);
        errorCount++;
      }
    }
    
    // Show deletion summary
    console.log('\n📊 Deletion Summary:');
    console.log('=' .repeat(30));
    console.log(`✅ Successfully deleted: ${deletedCount} records`);
    console.log(`❌ Errors: ${errorCount} records`);
    console.log(`📁 Total records processed: ${orphanedRecords.length}`);
    console.log(`🗑️ Total used days removed: ${totalUsedDays}`);
    
    if (errorCount > 0) {
      console.log('\n⚠️ Some records could not be deleted. Check the error messages above.');
    } else {
      console.log('\n🎉 All orphaned leave used records have been successfully deleted!');
    }
    
  } catch (error) {
    console.error('❌ Cleanup failed:', error);
    console.error('Error details:', error.message);
    if (error.stack) {
      console.error('Stack trace:', error.stack);
    }
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the cleanup
if (require.main === module) {
  deleteOrphanedLeaveUsed();
}

module.exports = { deleteOrphanedLeaveUsed };
