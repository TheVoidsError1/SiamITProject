/**
 * Delete Orphaned Leave Quota Script
 * Run with: node scripts/delete-orphaned-leave-quota.js --confirm
 * 
 * This script permanently deletes leave quota records that reference non-existent or deleted leave types.
 * These orphaned records are safe to remove as they reference invalid leave types.
 * 
 * ⚠️ WARNING: This script will permanently delete data from the database.
 * Always run the check script first to see what will be deleted.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function deleteOrphanedLeaveQuota() {
  try {
    console.log('🗑️ Orphaned Leave Quota Cleaner');
    console.log('================================');
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const isConfirmed = args.includes('--confirm');
    
    if (!isConfirmed) {
      console.log('⚠️ WARNING: This script will permanently delete orphaned leave quota records!');
      console.log('📋 To proceed, you must run this script with the --confirm flag:');
      console.log('   node scripts/delete-orphaned-leave-quota.js --confirm');
      console.log('\n💡 First, run the check script to see what will be deleted:');
      console.log('   node scripts/check-orphaned-leave-quota.js');
      return;
    }
    
    console.log('✅ Confirmation flag detected. Proceeding with deletion...');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const leaveQuotaRepo = AppDataSource.getRepository('LeaveQuota');
    const leaveTypeRepo = AppDataSource.getRepository('LeaveType');
    
    // Get all leave quota records
    const allLeaveQuotas = await leaveQuotaRepo.find();
    console.log(`📊 Found ${allLeaveQuotas.length} total leave quota records`);
    
    // Get all valid leave types (active and not soft-deleted)
    const validLeaveTypes = await leaveTypeRepo.find({
      where: {
        deleted_at: null,
        is_active: true
      }
    });
    console.log(`✅ Found ${validLeaveTypes.length} valid (active) leave types`);
    
    // Create set for faster lookup
    const validLeaveTypeIds = new Set(validLeaveTypes.map(lt => lt.id));
    
    // Find orphaned leave quota records
    const orphanedQuotas = [];
    
    for (const quota of allLeaveQuotas) {
      const isLeaveTypeValid = validLeaveTypeIds.has(quota.leaveTypeId);
      
      if (!isLeaveTypeValid) {
        // Find the leave type to get more details
        const leaveType = await leaveTypeRepo.findOne({
          where: { id: quota.leaveTypeId }
        });
        
        orphanedQuotas.push({
          ...quota,
          leaveTypeInfo: leaveType ? {
            nameEn: leaveType.leave_type_en,
            nameTh: leaveType.leave_type_th,
            deletedAt: leaveType.deleted_at,
            isActive: leaveType.is_active,
            status: leaveType.deleted_at ? 'Soft-deleted' : (leaveType.is_active ? 'Active' : 'Inactive')
          } : {
            nameEn: 'Unknown',
            nameTh: 'Unknown',
            deletedAt: null,
            isActive: false,
            status: 'Not Found'
          }
        });
      }
    }
    
    console.log(`🔍 Found ${orphanedQuotas.length} orphaned leave quota records`);
    
    if (orphanedQuotas.length === 0) {
      console.log('✅ No orphaned leave quota records found. Nothing to delete.');
      return;
    }
    
    // Show what will be deleted
    console.log('\n📋 Records to be deleted:');
    console.log('=' .repeat(80));
    
    orphanedQuotas.forEach((quota, index) => {
      console.log(`${index + 1}. Leave Quota ID: ${quota.id}`);
      console.log(`   Position ID: ${quota.positionId}`);
      console.log(`   Leave Type ID: ${quota.leaveTypeId}`);
      console.log(`   Leave Type: ${quota.leaveTypeInfo.nameEn || 'N/A'} (${quota.leaveTypeInfo.nameTh || 'N/A'})`);
      console.log(`   Leave Type Status: ${quota.leaveTypeInfo.status}`);
      console.log(`   Quota: ${quota.quota}`);
      console.log('   ' + '-'.repeat(50));
    });
    
    // Calculate total quota that will be removed
    const totalQuotaToRemove = orphanedQuotas.reduce((sum, quota) => sum + quota.quota, 0);
    console.log(`\n📊 Deletion Summary:`);
    console.log(`Total records to delete: ${orphanedQuotas.length}`);
    console.log(`Total quota to remove: ${totalQuotaToRemove}`);
    
    // Perform deletion
    console.log('\n🗑️ Starting deletion process...');
    let deletedCount = 0;
    let failedCount = 0;
    const failedDeletions = [];
    
    for (const quota of orphanedQuotas) {
      try {
        console.log(`   🗑️ Deleting: ${quota.id} (${quota.leaveTypeInfo.nameEn || 'Unknown'})`);
        
        // Permanently delete the record
        await leaveQuotaRepo.remove(quota);
        deletedCount++;
        
        console.log(`   ✅ Successfully deleted: ${quota.id}`);
        
      } catch (deleteError) {
        console.error(`   ❌ Failed to delete ${quota.id}:`, deleteError.message);
        failedCount++;
        failedDeletions.push({
          quota,
          error: deleteError.message
        });
      }
    }
    
    // Show results
    console.log('\n📊 Deletion Results:');
    console.log('=' .repeat(40));
    console.log(`✅ Successfully deleted: ${deletedCount} records`);
    console.log(`❌ Failed to delete: ${failedCount} records`);
    
    if (failedDeletions.length > 0) {
      console.log('\n❌ Failed deletions:');
      failedDeletions.forEach((failure, index) => {
        console.log(`${index + 1}. ID: ${failure.quota.id} - Error: ${failure.error}`);
      });
    }
    
    // Show breakdown by leave type status
    const statusBreakdown = {};
    orphanedQuotas.forEach(quota => {
      const status = quota.leaveTypeInfo.status;
      statusBreakdown[status] = (statusBreakdown[status] || 0) + 1;
    });
    
    console.log('\n📈 Deleted records by leave type status:');
    console.log('=' .repeat(50));
    Object.entries(statusBreakdown).forEach(([status, count]) => {
      console.log(`${status}: ${count} records`);
    });
    
    if (deletedCount > 0) {
      console.log('\n✅ Orphaned leave quota cleanup completed successfully!');
      console.log(`🗑️ Removed ${deletedCount} orphaned records`);
      console.log(`💾 Freed up quota allocation: ${totalQuotaToRemove}`);
    } else {
      console.log('\n⚠️ No records were deleted due to errors.');
    }
    
  } catch (error) {
    console.error('❌ Deletion failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the deletion
if (require.main === module) {
  deleteOrphanedLeaveQuota();
}

module.exports = { deleteOrphanedLeaveQuota };
