/**
 * Check Leave Type Usage Script
 * Run with: node scripts/check-leave-type-usage.js
 * 
 * This script analyzes how leave types are being used across the system,
 * showing usage statistics and identifying unused or rarely used leave types.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource, MoreThanOrEqual } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function checkLeaveTypeUsage() {
  try {
    console.log('🚀 Starting Leave Type Usage Analysis...');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const leaveTypeRepo = AppDataSource.getRepository('LeaveType');
    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    
    // Get all leave types (including soft-deleted ones)
    const allLeaveTypes = await leaveTypeRepo.find();
    console.log(`📊 Total leave types found: ${allLeaveTypes.length}`);
    
    // Separate active and inactive leave types
    const activeLeaveTypes = allLeaveTypes.filter(lt => !lt.deleted_at && lt.is_active);
    const inactiveLeaveTypes = allLeaveTypes.filter(lt => lt.deleted_at || !lt.is_active);
    
    console.log(`✅ Active leave types: ${activeLeaveTypes.length}`);
    console.log(`❌ Inactive/Deleted leave types: ${inactiveLeaveTypes.length}`);
    
    // Analyze usage for each active leave type
    console.log('\n🔍 Analyzing usage for active leave types...');
    const usageStats = [];
    
    for (const leaveType of activeLeaveTypes) {
      // Count total requests for this leave type
      const totalRequests = await leaveRequestRepo.count({
        where: { leaveType: leaveType.id }
      });
      
      // Count requests by status
      const pendingRequests = await leaveRequestRepo.count({
        where: { 
          leaveType: leaveType.id,
          status: 'pending'
        }
      });
      
      const approvedRequests = await leaveRequestRepo.count({
        where: { 
          leaveType: leaveType.id,
          status: 'approved'
        }
      });
      
      const rejectedRequests = await leaveRequestRepo.count({
        where: { 
          leaveType: leaveType.id,
          status: 'rejected'
        }
      });
      
      // Get recent usage (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const recentRequests = await leaveRequestRepo.count({
        where: { 
          leaveType: leaveType.id,
          createdAt: MoreThanOrEqual(thirtyDaysAgo)
        }
      });
      
      usageStats.push({
        id: leaveType.id,
        nameEn: leaveType.leave_type_en,
        nameTh: leaveType.leave_type_th,
        requireAttachment: leaveType.require_attachment,
        totalRequests,
        pendingRequests,
        approvedRequests,
        rejectedRequests,
        recentRequests,
        isActive: leaveType.is_active
      });
    }
    
    // Sort by total usage (descending)
    usageStats.sort((a, b) => b.totalRequests - a.totalRequests);
    
    // Display usage statistics
    console.log('\n📈 Leave Type Usage Statistics:');
    console.log('=' .repeat(100));
    
    usageStats.forEach((stat, index) => {
      console.log(`${index + 1}. ${stat.nameEn || 'N/A'} (${stat.nameTh || 'N/A'})`);
      console.log(`   ID: ${stat.id}`);
      console.log(`   Total Requests: ${stat.totalRequests}`);
      console.log(`   - Pending: ${stat.pendingRequests}`);
      console.log(`   - Approved: ${stat.approvedRequests}`);
      console.log(`   - Rejected: ${stat.rejectedRequests}`);
      console.log(`   Recent (30 days): ${stat.recentRequests}`);
      console.log(`   Requires Attachment: ${stat.requireAttachment ? 'Yes' : 'No'}`);
      console.log(`   Status: ${stat.isActive ? 'Active' : 'Inactive'}`);
      console.log('   ' + '-'.repeat(50));
    });
    
    // Identify unused leave types
    const unusedTypes = usageStats.filter(stat => stat.totalRequests === 0);
    const rarelyUsedTypes = usageStats.filter(stat => stat.totalRequests > 0 && stat.totalRequests <= 5);
    
    console.log('\n⚠️ Analysis Results:');
    console.log('=' .repeat(50));
    
    if (unusedTypes.length > 0) {
      console.log(`🚫 Unused leave types (0 requests): ${unusedTypes.length}`);
      unusedTypes.forEach(type => {
        console.log(`   - ${type.nameEn || 'N/A'} (${type.nameTh || 'N/A'})`);
      });
    }
    
    if (rarelyUsedTypes.length > 0) {
      console.log(`⚠️ Rarely used leave types (1-5 requests): ${rarelyUsedTypes.length}`);
      rarelyUsedTypes.forEach(type => {
        console.log(`   - ${type.nameEn || 'N/A'} (${type.nameTh || 'N/A'}) - ${type.totalRequests} requests`);
      });
    }
    
    // Check inactive/deleted types for usage and delete if unused
    if (inactiveLeaveTypes.length > 0) {
      console.log('\n🗑️ Checking Inactive/Deleted Leave Types for usage...');
      const deletableTypes = [];
      
      for (const type of inactiveLeaveTypes) {
        // Check if this leave type is used in any leave requests
        const usageCount = await leaveRequestRepo.count({
          where: { leaveType: type.id }
        });
        
        const status = type.deleted_at ? 'Soft-deleted' : 'Inactive';
        const deletedDate = type.deleted_at ? ` (${type.deleted_at})` : '';
        
        if (usageCount === 0) {
          console.log(`   ✅ ${type.leave_type_en || 'N/A'} (${type.leave_type_th || 'N/A'}) - ${status}${deletedDate} - NO USAGE - Safe to delete`);
          deletableTypes.push(type);
        } else {
          console.log(`   ⚠️ ${type.leave_type_en || 'N/A'} (${type.leave_type_th || 'N/A'}) - ${status}${deletedDate} - HAS ${usageCount} REQUESTS - Keep for now`);
        }
      }
      
      // Delete unused inactive types
      if (deletableTypes.length > 0) {
        console.log(`\n🗑️ Found ${deletableTypes.length} inactive leave types with no usage - proceeding to delete...`);
        
        for (const type of deletableTypes) {
          try {
            console.log(`   🗑️ Deleting: ${type.leave_type_en || 'N/A'} (${type.leave_type_th || 'N/A'}) - ID: ${type.id}`);
            
            // Permanently delete from database
            await leaveTypeRepo.remove(type);
            console.log(`   ✅ Successfully deleted: ${type.leave_type_en || 'N/A'}`);
            
          } catch (deleteError) {
            console.error(`   ❌ Failed to delete ${type.leave_type_en || 'N/A'}:`, deleteError.message);
          }
        }
        
        console.log(`\n✅ Deletion process completed. Removed ${deletableTypes.length} unused inactive leave types.`);
      } else {
        console.log('\nℹ️ No inactive leave types found that are safe to delete.');
      }
    }
    
    // Summary
    console.log('\n📊 Summary:');
    console.log('=' .repeat(30));
    console.log(`Total Leave Types: ${allLeaveTypes.length}`);
    console.log(`Active Types: ${activeLeaveTypes.length}`);
    console.log(`Inactive/Deleted Types: ${inactiveLeaveTypes.length}`);
    console.log(`Types with Usage: ${usageStats.filter(s => s.totalRequests > 0).length}`);
    console.log(`Unused Types: ${unusedTypes.length}`);
    console.log(`Rarely Used Types: ${rarelyUsedTypes.length}`);
    
    // Show deletion results if any
    if (typeof deletableTypes !== 'undefined' && deletableTypes.length > 0) {
      console.log(`🗑️ Deleted Unused Inactive Types: ${deletableTypes.length}`);
    }
    
    console.log('\n✅ Leave type usage analysis completed successfully!');
    
  } catch (error) {
    console.error('❌ Analysis failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the analysis
if (require.main === module) {
  checkLeaveTypeUsage();
}

module.exports = { checkLeaveTypeUsage };
