#!/usr/bin/env node

/**
 * Check Orphaned Leave Used Records Script
 * Run with: node scripts/check-orphaned-leave-used.js
 * 
 * This script identifies records in leave_used table that reference
 * non-existent or deleted users.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function checkOrphanedLeaveUsed() {
  try {
    console.log('🔍 Orphaned Leave Used Records Checker');
    console.log('======================================');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const userRepo = AppDataSource.getRepository('User');
    const leaveUsedRepo = AppDataSource.getRepository('LeaveUsed');
    
    // Get all users
    const allUsers = await userRepo.find();
    console.log(`👥 Found ${allUsers.length} total users in database`);
    
    // Create set of valid user IDs for faster lookup
    const validUserIds = new Set(allUsers.map(user => user.id));
    console.log(`📋 Valid user IDs: ${Array.from(validUserIds).join(', ')}`);
    
    // Get all leave used records
    const allLeaveUsed = await leaveUsedRepo.find();
    console.log(`📊 Found ${allLeaveUsed.length} total leave used records`);
    
    // Check each leave used record
    const orphanedRecords = [];
    const validRecords = [];
    
    for (const record of allLeaveUsed) {
      console.log(`\n🔍 Checking record ID: ${record.id}`);
      console.log(`   User ID: ${record.user_id}`);
      console.log(`   Leave Type ID: ${record.leave_type_id}`);
      console.log(`   Days: ${record.days}`);
      console.log(`   Hour: ${record.hour}`);
      console.log(`   Created At: ${record.created_at}`);
      
      if (record.user_id && !validUserIds.has(record.user_id)) {
        console.log(`   ❌ ORPHANED - User ID ${record.user_id} not found in User table`);
        orphanedRecords.push({
          ...record,
          userStatus: 'User Not Found'
        });
      } else if (record.user_id) {
        console.log(`   ✅ VALID - User ID ${record.user_id} exists in User table`);
        validRecords.push(record);
      } else {
        console.log(`   ⚠️  WARNING - No user ID specified`);
        validRecords.push(record);
      }
    }
    
    // Display summary
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total users in database: ${allUsers.length}`);
    console.log(`Total leave used records: ${allLeaveUsed.length}`);
    console.log(`Valid records: ${validRecords.length}`);
    console.log(`Orphaned records: ${orphanedRecords.length}`);
    
    if (orphanedRecords.length > 0) {
      console.log('\n🗑️ Orphaned Leave Used Records:');
      console.log('=' .repeat(60));
      
      orphanedRecords.forEach((record, index) => {
        console.log(`${index + 1}. Record ID: ${record.id}`);
        console.log(`   User ID: ${record.user_id} (${record.userStatus})`);
        console.log(`   Leave Type ID: ${record.leave_type_id}`);
        console.log(`   Days: ${record.days}`);
        console.log(`   Hour: ${record.hour}`);
        console.log(`   Created At: ${record.created_at}`);
        console.log('   ' + '-'.repeat(40));
      });
      
      // Calculate total used days that would be affected
      const totalUsedDays = orphanedRecords.reduce((sum, record) => sum + (record.days || 0), 0);
      console.log(`\n📊 Summary:`);
      console.log(`Total orphaned records: ${orphanedRecords.length}`);
      console.log(`Total used days affected: ${totalUsedDays}`);
      
      console.log('\n💡 To delete orphaned records, run:');
      console.log('node scripts/delete-orphaned-leave-used.js --confirm');
    } else {
      console.log('\n✅ No orphaned leave used records found!');
    }
    
    console.log('\n✅ Check completed successfully!');
    
  } catch (error) {
    console.error('❌ Check failed:', error);
    console.error('Error details:', error.message);
    if (error.stack) {
      console.error('Stack trace:', error.stack);
    }
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the check
if (require.main === module) {
  checkOrphanedLeaveUsed();
}

module.exports = { checkOrphanedLeaveUsed };
