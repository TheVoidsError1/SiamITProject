#!/usr/bin/env node

/**
 * Script to delete orphaned leave request attachment files
 * These are files that exist in the uploads folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource, Not } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const leaveRequestEntity = require('../EnityTable/leaveRequest.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [leaveRequestEntity],
});

function parseAttachments(val) {
  if (!val) return [];
  try {
    return JSON.parse(val);
  } catch (e) {
    return [];
  }
}

async function deleteOrphanedFiles() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    const leaveUploadsPath = config.getLeaveUploadsPath();
    
    // Get all leave requests with attachments
    const leaveRequests = await leaveRequestRepo.find({
      where: { attachments: Not(null) }
    });
    
    console.log(`📊 Found ${leaveRequests.length} leave requests with attachments`);
    
    // Collect all referenced file names
    const referencedFiles = new Set();
    leaveRequests.forEach(leave => {
      // Check attachments field (JSON array format)
      if (leave.attachments) {
        const attachments = parseAttachments(leave.attachments);
        attachments.forEach(file => referencedFiles.add(file));
      }
    });
    
    console.log(`📁 Found ${referencedFiles.size} referenced files in database`);
    
    // Get all files in uploads directory
    const uploadFiles = fs.readdirSync(leaveUploadsPath);
    console.log(`📂 Found ${uploadFiles.length} files in uploads directory`);
    
    // Find orphaned files
    const orphanedFiles = uploadFiles.filter(file => !referencedFiles.has(file));
    
    console.log(`\n🗑️  Found ${orphanedFiles.length} orphaned files`);
    
    if (orphanedFiles.length === 0) {
      console.log('✅ No orphaned files to delete.');
      return;
    }
    
    // Show orphaned files
    console.log('\nFiles to be deleted:');
    orphanedFiles.forEach((file, index) => {
      console.log(`  ${index + 1}. ${file}`);
    });
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('\n⚠️  WARNING: This will permanently delete orphaned files!');
      console.log('   To confirm deletion, run: node scripts/delete-orphaned-files.js --confirm');
      return;
    }
    
    console.log('\n🗑️  Proceeding with deletion...');
    
    let deletedCount = 0;
    let errorCount = 0;
    
    for (const file of orphanedFiles) {
      try {
        const filePath = path.join(leaveUploadsPath, file);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          console.log(`✅ Deleted: ${file}`);
          deletedCount++;
        } else {
          console.log(`⚠️  File not found: ${file}`);
        }
      } catch (error) {
        console.error(`❌ Error deleting ${file}:`, error.message);
        errorCount++;
      }
    }
    
    console.log('\n📊 Deletion Summary:');
    console.log(`✅ Successfully deleted: ${deletedCount} files`);
    console.log(`❌ Errors: ${errorCount} files`);
    console.log(`📁 Total orphaned files: ${orphanedFiles.length}`);

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🗑️  Orphaned Files Cleanup');
  console.log('==========================');
  deleteOrphanedFiles()
    .then(() => {
      console.log('✨ Cleanup completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Cleanup failed:', error.message);
      process.exit(1);
    });
}

module.exports = { deleteOrphanedFiles };
