/**
 * Check Orphaned Leave Quota Script
 * Run with: node scripts/check-orphaned-leave-quota.js
 * 
 * This script identifies leave quota records that reference non-existent or deleted leave types.
 * These orphaned records can be safely removed to maintain data integrity.
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function checkOrphanedLeaveQuota() {
  try {
    console.log('🔍 Orphaned Leave Quota Checker');
    console.log('================================');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Get repositories
    const leaveQuotaRepo = AppDataSource.getRepository('LeaveQuota');
    const leaveTypeRepo = AppDataSource.getRepository('LeaveType');
    const positionRepo = AppDataSource.getRepository('Position');
    
    // Get all leave quota records
    const allLeaveQuotas = await leaveQuotaRepo.find();
    console.log(`📊 Found ${allLeaveQuotas.length} total leave quota records`);
    
    // Get all valid leave types (active and not soft-deleted)
    const validLeaveTypes = await leaveTypeRepo.find({
      where: {
        deleted_at: null,
        is_active: true
      }
    });
    console.log(`✅ Found ${validLeaveTypes.length} valid (active) leave types`);
    
    // Get all positions for reference
    const allPositions = await positionRepo.find();
    console.log(`👥 Found ${allPositions.length} total positions`);
    
    // Create sets for faster lookup
    const validLeaveTypeIds = new Set(validLeaveTypes.map(lt => lt.id));
    const validPositionIds = new Set(allPositions.map(p => p.id));
    
    // Analyze leave quota records
    const orphanedQuotas = [];
    const validQuotas = [];
    const invalidPositionQuotas = [];
    
    for (const quota of allLeaveQuotas) {
      const isLeaveTypeValid = validLeaveTypeIds.has(quota.leaveTypeId);
      const isPositionValid = validPositionIds.has(quota.positionId);
      
      if (!isLeaveTypeValid) {
        // Find the leave type to get more details
        const leaveType = await leaveTypeRepo.findOne({
          where: { id: quota.leaveTypeId }
        });
        
        orphanedQuotas.push({
          ...quota,
          leaveTypeInfo: leaveType ? {
            nameEn: leaveType.leave_type_en,
            nameTh: leaveType.leave_type_th,
            deletedAt: leaveType.deleted_at,
            isActive: leaveType.is_active,
            status: leaveType.deleted_at ? 'Soft-deleted' : (leaveType.is_active ? 'Active' : 'Inactive')
          } : {
            nameEn: 'Unknown',
            nameTh: 'Unknown',
            deletedAt: null,
            isActive: false,
            status: 'Not Found'
          }
        });
      } else if (!isPositionValid) {
        invalidPositionQuotas.push({
          ...quota,
          positionStatus: 'Position Not Found'
        });
      } else {
        validQuotas.push(quota);
      }
    }
    
    // Display analysis results
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total leave quota records: ${allLeaveQuotas.length}`);
    console.log(`Valid records: ${validQuotas.length}`);
    console.log(`Orphaned leave type records: ${orphanedQuotas.length}`);
    console.log(`Invalid position records: ${invalidPositionQuotas.length}`);
    
    if (orphanedQuotas.length > 0) {
      console.log('\n🗑️ Orphaned leave quota records (can be safely deleted):');
      console.log('=' .repeat(80));
      
      orphanedQuotas.forEach((quota, index) => {
        console.log(`${index + 1}. Leave Quota ID: ${quota.id}`);
        console.log(`   Position ID: ${quota.positionId}`);
        console.log(`   Leave Type ID: ${quota.leaveTypeId}`);
        console.log(`   Leave Type: ${quota.leaveTypeInfo.nameEn || 'N/A'} (${quota.leaveTypeInfo.nameTh || 'N/A'})`);
        console.log(`   Leave Type Status: ${quota.leaveTypeInfo.status}`);
        if (quota.leaveTypeInfo.deletedAt) {
          console.log(`   Deleted At: ${quota.leaveTypeInfo.deletedAt}`);
        }
        console.log(`   Quota: ${quota.quota}`);
        console.log('   ' + '-'.repeat(50));
      });
      
      // Calculate total quota that would be freed
      const totalQuotaToRemove = orphanedQuotas.reduce((sum, quota) => sum + quota.quota, 0);
      console.log(`\n📊 Summary of orphaned records:`);
      console.log(`Total records to remove: ${orphanedQuotas.length}`);
      console.log(`Total quota to remove: ${totalQuotaToRemove}`);
      
      console.log('\n💡 To delete orphaned leave quota records, run:');
      console.log('node scripts/delete-orphaned-leave-quota.js --confirm');
    } else {
      console.log('\n✅ No orphaned leave quota records found!');
    }
    
    if (invalidPositionQuotas.length > 0) {
      console.log('\n⚠️ Leave quota records with invalid positions:');
      console.log('=' .repeat(60));
      
      invalidPositionQuotas.forEach((quota, index) => {
        console.log(`${index + 1}. Leave Quota ID: ${quota.id}`);
        console.log(`   Position ID: ${quota.positionId} (${quota.positionStatus})`);
        console.log(`   Leave Type ID: ${quota.leaveTypeId}`);
        console.log(`   Quota: ${quota.quota}`);
        console.log('   ' + '-'.repeat(40));
      });
      
      console.log('\n⚠️ These records have invalid position references and should be reviewed manually.');
    }
    
    // Show breakdown by leave type status
    if (orphanedQuotas.length > 0) {
      const statusBreakdown = {};
      orphanedQuotas.forEach(quota => {
        const status = quota.leaveTypeInfo.status;
        statusBreakdown[status] = (statusBreakdown[status] || 0) + 1;
      });
      
      console.log('\n📈 Breakdown by leave type status:');
      console.log('=' .repeat(40));
      Object.entries(statusBreakdown).forEach(([status, count]) => {
        console.log(`${status}: ${count} records`);
      });
    }
    
    console.log('\n✅ Orphaned leave quota check completed successfully!');
    
  } catch (error) {
    console.error('❌ Check failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the check
if (require.main === module) {
  checkOrphanedLeaveQuota();
}

module.exports = { checkOrphanedLeaveQuota };
