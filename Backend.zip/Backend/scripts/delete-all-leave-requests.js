#!/usr/bin/env node

/**
 * Script to delete all leave requests from the database
 * 
 * WARNING: This script will permanently delete ALL leave requests from the database.
 * Make sure you have a backup before running this script.
 * 
 * Usage: node scripts/delete-all-leave-requests.js [--confirm]
 */

require('reflect-metadata');
const { DataSource, Not } = require('typeorm');
const config = require('../config');

// Import entity schemas
const leaveRequestEntity = require('../EnityTable/leaveRequest.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false, // Don't auto-sync for this script
  logging: true, // Enable logging to see what's happening
  entities: [leaveRequestEntity],
});

async function deleteAllLeaveRequests() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    
    // Get count of existing leave requests
    const totalCount = await leaveRequestRepo.count();
    console.log(`📊 Found ${totalCount} leave requests in the database`);

    if (totalCount === 0) {
      console.log('ℹ️  No leave requests found. Nothing to delete.');
      return;
    }

    // Show some sample data before deletion
    console.log('\n📋 Sample leave requests (first 5):');
    const sampleRequests = await leaveRequestRepo.find({
      take: 5,
      order: { createdAt: 'DESC' }
    });

    sampleRequests.forEach((request, index) => {
      console.log(`  ${index + 1}. ID: ${request.id}, Employee: ${request.Repid}, Type: ${request.leaveType}, Status: ${request.status}, Created: ${request.createdAt}`);
    });

    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');

    if (!confirmed) {
      console.log('\n⚠️  WARNING: This will permanently delete ALL leave requests!');
      console.log('   To confirm deletion, run: node scripts/delete-all-leave-requests.js --confirm');
      console.log('   Make sure you have a backup before proceeding!');
      return;
    }

    console.log('\n🗑️  Proceeding with deletion...');
    
    // First, get all leave requests to delete their attachment files
    const allLeaveRequests = await leaveRequestRepo.find({
      where: { attachments: Not(null) }
    });
    
    console.log(`📁 Found ${allLeaveRequests.length} leave requests with attachments`);
    
    // Delete attachment files first
    let filesDeleted = 0;
    const fs = require('fs');
    const path = require('path');
    const config = require('../config');
    
    function parseAttachments(val) {
      if (!val) return [];
      try {
        return JSON.parse(val);
      } catch (e) {
        return [];
      }
    }
    
    for (const leave of allLeaveRequests) {
      if (leave.attachments) {
        try {
          const attachments = parseAttachments(leave.attachments);
          const leaveUploadsPath = config.getLeaveUploadsPath();
          
          for (const attachment of attachments) {
            const filePath = path.join(leaveUploadsPath, attachment);
            if (fs.existsSync(filePath)) {
              try {
                fs.unlinkSync(filePath);
                filesDeleted++;
                console.log(`✅ HARD DELETED file: ${attachment}`);
              } catch (fileError) {
                console.error(`❌ Failed to delete file ${attachment}:`, fileError.message);
                // Try force delete
                try {
                  fs.rmSync(filePath, { force: true });
                  filesDeleted++;
                  console.log(`✅ Force deleted: ${attachment}`);
                } catch (forceError) {
                  console.error(`❌ Force delete failed for ${attachment}:`, forceError.message);
                }
              }
            }
          }
        } catch (error) {
          console.error(`❌ Error processing attachments for leave ${leave.id}:`, error.message);
        }
      }
    }
    
    console.log(`📁 Deleted ${filesDeleted} attachment files`);
    
    // Now delete all leave requests from database
    const deleteResult = await leaveRequestRepo.delete({});
    
    console.log(`✅ Successfully deleted ${deleteResult.affected} leave requests`);
    console.log(`📁 Successfully deleted ${filesDeleted} attachment files`);
    console.log('🎉 All leave requests and files have been permanently removed');

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🚀 Leave Request Deletion Script');
  console.log('================================');
  deleteAllLeaveRequests()
    .then(() => {
      console.log('✨ Script completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Script failed:', error.message);
      process.exit(1);
    });
}

module.exports = { deleteAllLeaveRequests };
