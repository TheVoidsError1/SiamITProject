#!/usr/bin/env node

/**
 * Script to check for orphaned announcement image files
 * These are files that exist in the uploads/announcements folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const announcementsEntity = require('../EnityTable/announcements.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [announcementsEntity],
});

async function checkOrphanedAnnouncements() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const announcementRepo = AppDataSource.getRepository('Announcements');
    const announcementsUploadPath = path.join(__dirname, '../uploads/announcements');
    
    // Get all announcements with images
    const announcements = await announcementRepo.find();
    
    console.log(`📊 Found ${announcements.length} total announcements in database`);
    
    // Collect all referenced announcement image file names
    const referencedImages = new Set();
    let announcementsWithImages = 0;
    
    announcements.forEach(announcement => {
      if (announcement.Image && announcement.Image.trim() !== '') {
        const fileName = announcement.Image;
        referencedImages.add(fileName);
        announcementsWithImages++;
      }
    });
    
    console.log(`🖼️  Found ${announcementsWithImages} announcements with images`);
    console.log(`📁 Found ${referencedImages.size} unique image files referenced in database`);
    
    // Get all files in announcements uploads directory
    const uploadFiles = fs.readdirSync(announcementsUploadPath);
    console.log(`📂 Found ${uploadFiles.length} files in announcements directory`);
    
    // Find orphaned announcement image files
    const orphanedImages = uploadFiles.filter(file => !referencedImages.has(file));
    
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total image files in uploads: ${uploadFiles.length}`);
    console.log(`Referenced in database: ${referencedImages.size}`);
    console.log(`Orphaned images: ${orphanedImages.length}`);
    
    // Debug: Show referenced files
    if (referencedImages.size > 0) {
      console.log('\n📋 Referenced announcement images in database:');
      Array.from(referencedImages).forEach((file, index) => {
        console.log(`  ${index + 1}. ${file}`);
      });
    }
    
    // Debug: Show all files in directory
    console.log('\n📂 All files in announcements directory:');
    uploadFiles.forEach((file, index) => {
      const isReferenced = referencedImages.has(file);
      const status = isReferenced ? '✅ REFERENCED' : '❌ ORPHANED';
      console.log(`  ${index + 1}. ${file} - ${status}`);
    });
    
    if (orphanedImages.length > 0) {
      console.log('\n🗑️  Orphaned announcement images (can be safely deleted):');
      orphanedImages.forEach((file, index) => {
        const filePath = path.join(announcementsUploadPath, file);
        const stats = fs.statSync(filePath);
        const fileSize = (stats.size / 1024).toFixed(2); // Size in KB
        const modifiedDate = stats.mtime.toLocaleDateString();
        console.log(`  ${index + 1}. ${file} (${fileSize} KB, modified: ${modifiedDate})`);
      });
      
      console.log('\n💡 To delete orphaned announcement images, run:');
      console.log('node scripts/delete-orphaned-announcements.js --confirm');
    } else {
      console.log('\n✅ No orphaned announcement images found. All files are properly referenced.');
    }

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🔍 Orphaned Announcement Images Checker');
  console.log('======================================');
  checkOrphanedAnnouncements()
    .then(() => {
      console.log('✨ Check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Check failed:', error.message);
      process.exit(1);
    });
}

module.exports = { checkOrphanedAnnouncements };
