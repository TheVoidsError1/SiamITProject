#!/usr/bin/env node

/**
 * Script to delete orphaned announcement image files
 * These are files that exist in the uploads/announcements folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const announcementsEntity = require('../EnityTable/announcements.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [announcementsEntity],
});

async function deleteOrphanedAnnouncements() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const announcementRepo = AppDataSource.getRepository('Announcements');
    const announcementsUploadPath = path.join(__dirname, '../uploads/announcements');
    
    // Get all announcements with images
    const announcements = await announcementRepo.find();
    
    console.log(`📊 Found ${announcements.length} total announcements in database`);
    
    // Collect all referenced announcement image file names
    const referencedImages = new Set();
    let announcementsWithImages = 0;
    
    announcements.forEach(announcement => {
      if (announcement.Image && announcement.Image.trim() !== '') {
        const fileName = announcement.Image;
        referencedImages.add(fileName);
        announcementsWithImages++;
      }
    });
    
    console.log(`🖼️  Found ${announcementsWithImages} announcements with images`);
    console.log(`📁 Found ${referencedImages.size} unique image files referenced in database`);
    
    // Get all files in announcements uploads directory
    const uploadFiles = fs.readdirSync(announcementsUploadPath);
    console.log(`📂 Found ${uploadFiles.length} files in announcements directory`);
    
    // Find orphaned announcement image files
    const orphanedImages = uploadFiles.filter(file => !referencedImages.has(file));
    
    console.log(`\n🗑️  Found ${orphanedImages.length} orphaned announcement images`);
    
    if (orphanedImages.length === 0) {
      console.log('✅ No orphaned announcement images to delete.');
      return;
    }
    
    // Show orphaned images with details
    console.log('\nFiles to be deleted:');
    let totalSize = 0;
    orphanedImages.forEach((file, index) => {
      const filePath = path.join(announcementsUploadPath, file);
      const stats = fs.statSync(filePath);
      const fileSize = stats.size;
      totalSize += fileSize;
      const fileSizeKB = (fileSize / 1024).toFixed(2);
      const modifiedDate = stats.mtime.toLocaleDateString();
      console.log(`  ${index + 1}. ${file} (${fileSizeKB} KB, modified: ${modifiedDate})`);
    });
    
    const totalSizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    console.log(`\n📊 Total size to be freed: ${totalSizeMB} MB`);
    
    // Check for confirmation flag
    const args = process.argv.slice(2);
    const confirmed = args.includes('--confirm');
    
    if (!confirmed) {
      console.log('\n⚠️  WARNING: This will permanently delete orphaned announcement images!');
      console.log('   To confirm deletion, run: node scripts/delete-orphaned-announcements.js --confirm');
      return;
    }
    
    console.log('\n🗑️  Proceeding with HARD DELETE...');
    
    let deletedCount = 0;
    let errorCount = 0;
    let freedSpace = 0;
    
    for (const file of orphanedImages) {
      try {
        const filePath = path.join(announcementsUploadPath, file);
        const stats = fs.statSync(filePath);
        const fileSize = stats.size;
        
        if (fs.existsSync(filePath)) {
          // Force delete the announcement image file (hard delete)
          fs.unlinkSync(filePath);
          
          // Verify file is actually deleted
          if (!fs.existsSync(filePath)) {
            console.log(`✅ HARD DELETED: ${file}`);
            deletedCount++;
            freedSpace += fileSize;
          } else {
            console.error(`❌ FAILED to delete: ${file} - file still exists`);
            
            // Try alternative deletion method
            try {
              fs.rmSync(filePath, { force: true });
              if (!fs.existsSync(filePath)) {
                console.log(`✅ Force deleted: ${file}`);
                deletedCount++;
                freedSpace += fileSize;
              } else {
                console.error(`❌ Force delete also failed for: ${file}`);
                errorCount++;
              }
            } catch (forceDeleteError) {
              console.error(`❌ Force delete failed for ${file}:`, forceDeleteError.message);
              errorCount++;
            }
          }
        } else {
          console.log(`⚠️  File not found (already deleted?): ${file}`);
        }
      } catch (error) {
        console.error(`❌ Error deleting ${file}:`, error.message);
        errorCount++;
      }
    }
    
    const freedSpaceMB = (freedSpace / (1024 * 1024)).toFixed(2);
    
    console.log('\n📊 Deletion Summary:');
    console.log(`✅ Successfully deleted: ${deletedCount} announcement images`);
    console.log(`❌ Errors: ${errorCount} files`);
    console.log(`📁 Total orphaned images: ${orphanedImages.length}`);
    console.log(`💾 Space freed: ${freedSpaceMB} MB`);

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🗑️  Orphaned Announcement Images Cleanup');
  console.log('=======================================');
  deleteOrphanedAnnouncements()
    .then(() => {
      console.log('✨ Cleanup completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Cleanup failed:', error.message);
      process.exit(1);
    });
}

module.exports = { deleteOrphanedAnnouncements };
