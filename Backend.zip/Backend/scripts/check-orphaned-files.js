#!/usr/bin/env node

/**
 * Script to check for orphaned leave request attachment files
 * These are files that exist in the uploads folder but are no longer referenced in the database
 */

require('reflect-metadata');
const { DataSource, Not } = require('typeorm');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Import entity schemas
const leaveRequestEntity = require('../EnityTable/leaveRequest.entity.js');

// Initialize DataSource
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false,
  logging: false,
  entities: [leaveRequestEntity],
});

function parseAttachments(val) {
  if (!val) return [];
  try {
    return JSON.parse(val);
  } catch (e) {
    return [];
  }
}

async function checkOrphanedFiles() {
  try {
    console.log('🔄 Initializing database connection...');
    await AppDataSource.initialize();
    console.log('✅ Database connection established');

    const leaveRequestRepo = AppDataSource.getRepository('LeaveRequest');
    const leaveUploadsPath = config.getLeaveUploadsPath();
    
    // Get all leave requests with attachments
    const leaveRequests = await leaveRequestRepo.find({
      where: { attachments: Not(null) }
    });
    
    console.log(`📊 Found ${leaveRequests.length} leave requests with attachments`);
    
    // Collect all referenced file names
    const referencedFiles = new Set();
    leaveRequests.forEach(leave => {
      // Check attachments field (JSON array format)
      if (leave.attachments) {
        const attachments = parseAttachments(leave.attachments);
        attachments.forEach(file => referencedFiles.add(file));
      }
    });
    
    console.log(`📁 Found ${referencedFiles.size} referenced files in database`);
    
    // Get all files in uploads directory
    const uploadFiles = fs.readdirSync(leaveUploadsPath);
    console.log(`📂 Found ${uploadFiles.length} files in uploads directory`);
    
    // Find orphaned files
    const orphanedFiles = uploadFiles.filter(file => !referencedFiles.has(file));
    
    console.log('\n🔍 Analysis Results:');
    console.log('==================');
    console.log(`Total files in uploads: ${uploadFiles.length}`);
    console.log(`Referenced in database: ${referencedFiles.size}`);
    console.log(`Orphaned files: ${orphanedFiles.length}`);
    
    if (orphanedFiles.length > 0) {
      console.log('\n🗑️  Orphaned files (can be safely deleted):');
      orphanedFiles.forEach((file, index) => {
        console.log(`  ${index + 1}. ${file}`);
      });
      
      console.log('\n💡 To delete orphaned files, run:');
      console.log('node scripts/delete-orphaned-files.js --confirm');
    } else {
      console.log('\n✅ No orphaned files found. All files are properly referenced.');
    }

  } catch (error) {
    console.error('❌ Error occurred:', error.message);
    process.exit(1);
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
  }
}

// Handle script execution
if (require.main === module) {
  console.log('🔍 Orphaned Files Checker');
  console.log('========================');
  checkOrphanedFiles()
    .then(() => {
      console.log('✨ Check completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Check failed:', error.message);
      process.exit(1);
    });
}

module.exports = { checkOrphanedFiles };
