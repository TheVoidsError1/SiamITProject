/**
 * Test script for Leave Type Cleanup Service
 * Run with: node scripts/test-leave-type-cleanup.js
 */

require('dotenv').config();
require('reflect-metadata');
const { DataSource } = require('typeorm');
const config = require('../config');
const LeaveTypeCleanupService = require('../utils/leaveTypeCleanupService');

// TypeORM DataSource config
const AppDataSource = new DataSource({
  type: config.database.type,
  host: config.database.host,
  port: config.database.port,
  username: config.database.username,
  password: config.database.password,
  database: config.database.database,
  synchronize: false, // Don't auto-sync during testing
  logging: false,
  entities: [
    require('../EnityTable/User.entity.js'),
    require('../EnityTable/leaveRequest.entity.js'),
    require('../EnityTable/position.js'),
    require('../EnityTable/leaveType.js'),
    require('../EnityTable/department.js'),
    require('../EnityTable/leaveQuota.js'),
    require('../EnityTable/announcements.js'),
    require('../EnityTable/customHoliday.js'),
    require('../EnityTable/leave_use.js')
  ],
});

async function testLeaveTypeCleanup() {
  try {
    console.log('🚀 Starting Leave Type Cleanup Service test...');
    
    // Initialize database connection
    await AppDataSource.initialize();
    console.log('✅ Database connection established');
    
    // Create cleanup service instance
    const cleanupService = new LeaveTypeCleanupService(AppDataSource);
    console.log('✅ Cleanup service created');
    
    // Test 1: Check all soft-deleted leave types
    console.log('\n🔍 Test 1: Checking all soft-deleted leave types...');
    const leaveTypeRepo = AppDataSource.getRepository('LeaveType');
    const allLeaveTypes = await leaveTypeRepo.find();
    const softDeletedTypes = allLeaveTypes.filter(lt => lt.deleted_at);
    
    console.log(`📊 Total leave types: ${allLeaveTypes.length}`);
    console.log(`🗑️ Soft-deleted types: ${softDeletedTypes.length}`);
    
    if (softDeletedTypes.length > 0) {
      console.log('📋 Soft-deleted leave types:');
      softDeletedTypes.forEach((lt, index) => {
        console.log(`  ${index + 1}. ID: ${lt.id}, Name: ${lt.leave_type_en || lt.leave_type_th}, Deleted: ${lt.deleted_at}`);
      });
      
      // Test 2: Check if first soft-deleted type can be permanently deleted
      const firstSoftDeleted = softDeletedTypes[0];
      console.log(`\n🔍 Test 2: Checking if leave type ${firstSoftDeleted.id} can be permanently deleted...`);
      
      const canDelete = await cleanupService.canPermanentlyDeleteLeaveType(firstSoftDeleted.id);
      console.log('📋 Deletion eligibility check result:', canDelete);
      
      if (canDelete.canDelete) {
        console.log('✅ Leave type can be permanently deleted');
        
        // Test 3: Try to permanently delete (optional - uncomment to test)
        /*
        console.log('\n🗑️ Test 3: Attempting permanent deletion...');
        const deleteResult = await cleanupService.permanentlyDeleteLeaveType(firstSoftDeleted.id);
        console.log('✅ Permanent deletion result:', deleteResult);
        */
      } else {
        console.log('⚠️ Leave type cannot be permanently deleted:', canDelete.reason);
      }
    } else {
      console.log('ℹ️ No soft-deleted leave types found to test');
    }
    
    // Test 4: Run auto-cleanup (dry run - won't actually delete anything if not safe)
    console.log('\n🔄 Test 4: Running auto-cleanup check...');
    const cleanupResults = await cleanupService.autoCleanupOrphanedLeaveTypes();
    console.log('📊 Auto-cleanup results:', cleanupResults);
    
    console.log('\n✅ All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    console.error('Error stack:', error.stack);
  } finally {
    // Close database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('🔌 Database connection closed');
    }
    process.exit(0);
  }
}

// Run the test
if (require.main === module) {
  testLeaveTypeCleanup();
}

module.exports = { testLeaveTypeCleanup };
