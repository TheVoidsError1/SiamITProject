# Route Structure Documentation

This directory contains the centralized route organization for the SiamIT Leave Management System backend.

## Structure

```
routes/
├── index.js          # Main route aggregator
├── auth.js           # Authentication routes
├── leave.js          # Leave management routes
├── admin.js          # Admin and management routes
├── line.js           # LINE integration routes
└── README.md         # This documentation
```

## Route Organization

### 1. Authentication Routes (`auth.js`)
- **Register**: `/api/register`
- **Login**: `/api/login`
- **Profile**: `/api/profile/*`

### 2. Leave Management Routes (`leave.js`)
- **Leave Requests**: `/api/leave-request/*`
- **Leave History**: `/api/leave-history/*`
- **Leave Quota**: `/api/leave-quota/*`
- **Leave Types**: `/api/leave-types/*`

### 3. Admin & Management Routes (`admin.js`)
- **Positions**: `/api/positions/*`
- **Departments**: `/api/departments/*`
- **Employees**: `/api/employees/*`
- **Super Admin**: `/api/super-admin/*`
- **Admin Registration**: `/api/admin/*`
- **Dashboard**: `/api/dashboard/*`
- **Announcements**: `/api/announcements/*`
- **Custom Holidays**: `/api/custom-holidays/*`
- **Notifications**: `/api/notifications/*`

### 4. LINE Integration Routes (`line.js`)
- **Webhook**: `/api/line/webhook`
- **Send Notification**: `/api/line/send-notification`
- **Login URL**: `/api/line/login-url`
- **Callback**: `/api/line/callback`
- **Link Status**: `/api/line/link-status`
- **Unlink**: `/api/line/unlink`

## Benefits of This Structure

1. **Modularity**: Each functional area has its own route file
2. **Maintainability**: Easy to find and modify specific route groups
3. **Scalability**: Easy to add new route modules
4. **Clean Code**: Separates concerns and reduces clutter in main index.js
5. **Team Development**: Different developers can work on different route modules

## Usage

The routes are automatically initialized in `index.js`:

```javascript
const initializeRoutes = require('./routes');
const routes = initializeRoutes(AppDataSource);
app.use('/api', routes);
```

## Adding New Routes

1. Create a new route file in the `routes/` directory
2. Export a function that takes `AppDataSource` as parameter
3. Import and use the new route file in `routes/index.js`
4. The routes will be automatically available under `/api/`

## Example: Adding a New Route Module

```javascript
// routes/new-feature.js
const express = require('express');
const router = express.Router();
const newFeatureController = require('../api/NewFeatureController');

const initializeNewFeatureRoutes = (AppDataSource) => {
  router.use('/', newFeatureController(AppDataSource));
  return router;
};

module.exports = initializeNewFeatureRoutes;
```

Then add to `routes/index.js`:
```javascript
const newFeatureRoutes = require('./new-feature');
// ... in initializeRoutes function
router.use('/', newFeatureRoutes(AppDataSource));
``` 