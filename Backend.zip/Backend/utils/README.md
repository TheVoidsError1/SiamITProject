# Utility Functions Documentation

This directory contains centralized utility functions that eliminate code duplication across the SiamIT Leave Management System backend.

## Structure

```
utils/
├── index.js           # Main export file
├── dateTimeUtils.js   # Date and time calculations
├── authUtils.js       # Authentication and JWT operations
├── leaveUtils.js      # Leave management operations
├── responseUtils.js   # API response standardization
└── README.md          # This documentation
```

## Utility Categories

### 1. Date and Time Utilities (`dateTimeUtils.js`)

**Functions:**
- `convertToMinutes(h, m)` - Convert hours and minutes to total minutes
- `timeStringToDecimal(timeStr)` - Convert HH:MM string to decimal hours
- `calculateDaysBetween(startDate, endDate)` - Calculate days between dates
- `convertTimeRangeToDecimal(sh, sm, eh, em)` - Convert time range to decimal
- `toDayHour(val)` - Convert total hours to days and hours format
- `getEndOfDay(date)` - Create end of day date
- `getEndOfMonth(year, month)` - Create end of month date
- `getEndOfYear(year)` - Create end of year date
- `isValidTimeFormat(timeStr)` - Validate HH:MM format
- `calculateDurationHours(startTime, endTime)` - Calculate duration in hours

**Usage:**
```javascript
const { convertToMinutes, calculateDaysBetween, toDayHour } = require('../utils');

// Convert time to minutes
const minutes = convertToMinutes(9, 30); // 570

// Calculate days between dates
const days = calculateDaysBetween(startDate, endDate);

// Convert hours to days format
const { days, hours } = toDayHour(50); // { days: 2, hours: 2 }
```

### 2. Authentication Utilities (`authUtils.js`)

**Functions:**
- `hashPassword(password, saltRounds)` - Hash password with bcrypt
- `comparePassword(password, hashedPassword)` - Compare passwords
- `generateToken(payload, secret, expiresIn)` - Generate JWT token
- `verifyToken(token, secret)` - Verify JWT token
- `generateUserToken(user, email)` - Generate user token
- `generateAdminToken(user, role)` - Generate admin token
- `extractTokenFromHeader(authHeader)` - Extract token from header
- `isValidEmail(email)` - Validate email format
- `isValidUUID(uuid)` - Validate UUID format
- `createAuthError(message, statusCode)` - Create auth error response

**Usage:**
```javascript
const { hashPassword, generateToken, isValidEmail } = require('../utils');

// Hash password
const hashedPassword = await hashPassword('password123');

// Generate token
const token = generateToken({ userId: user.id, email: user.email });

// Validate email
const isValid = isValidEmail('user@example.com');
```

### 3. Leave Management Utilities (`leaveUtils.js`)

**Functions:**
- `normalizeLeaveType(type)` - Normalize leave type names
- `isWithinWorkingHours(timeStr)` - Check if time is within working hours
- `calculateWorkingHours(days)` - Calculate working hours for days
- `processLeaveData(leaves, AppDataSource)` - Process leave data with relations
- `validateLeaveRequest(leaveData)` - Validate leave request data
- `calculateLeaveStats(leaves)` - Calculate leave statistics
- `formatLeaveDuration(days, hours)` - Format duration for display
- `getLeaveStatusColor(status)` - Get status color for UI

**Usage:**
```javascript
const { normalizeLeaveType, validateLeaveRequest, processLeaveData } = require('../utils');

// Normalize leave type
const normalizedType = normalizeLeaveType('sick'); // 'Sick Leave'

// Validate leave request
const validation = validateLeaveRequest(leaveData);
if (!validation.isValid) {
  return sendValidationError(res, validation.errors);
}

// Process leave data
const processedLeaves = await processLeaveData(leaves, AppDataSource);
```

### 4. Response Utilities (`responseUtils.js`)

**Functions:**
- `sendSuccess(res, data, message, statusCode)` - Send success response
- `sendError(res, message, statusCode, data)` - Send error response
- `sendPaginated(res, data, page, limit, total, message)` - Send paginated response
- `asyncHandler(fn)` - Wrap async functions with error handling
- `sendValidationError(res, errors)` - Send validation error
- `sendNotFound(res, resource)` - Send not found error
- `sendUnauthorized(res, message)` - Send unauthorized error
- `sendForbidden(res, message)` - Send forbidden error
- `sendConflict(res, message)` - Send conflict error

**Usage:**
```javascript
const { sendSuccess, sendError, asyncHandler } = require('../utils');

// Send success response
sendSuccess(res, data, 'Operation successful', 200);

// Send error response
sendError(res, 'Something went wrong', 500);

// Wrap async function
const getUsers = asyncHandler(async (req, res) => {
  const users = await userRepo.find();
  sendSuccess(res, users, 'Users retrieved successfully');
});
```

## Benefits

1. **Code Reusability**: Eliminates duplicate code across controllers
2. **Consistency**: Ensures consistent behavior across the application
3. **Maintainability**: Changes in one place affect all usages
4. **Testing**: Easier to test utility functions in isolation
5. **Performance**: Optimized implementations used everywhere
6. **Documentation**: Clear documentation for each utility function

## Import Options

### Import all utilities:
```javascript
const utils = require('../utils');
const minutes = utils.convertToMinutes(9, 30);
```

### Import specific utilities:
```javascript
const { convertToMinutes, sendSuccess } = require('../utils');
```

### Import specific modules:
```javascript
const { dateTimeUtils, authUtils } = require('../utils');
const minutes = dateTimeUtils.convertToMinutes(9, 30);
```

## Migration Guide

When replacing duplicate code with utilities:

1. **Before:**
```javascript
// Duplicate code in multiple files
const hashedPassword = await bcrypt.hash(password, 10);
const days = Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;
res.status(200).json({ success: true, data: result });
```

2. **After:**
```javascript
// Using utilities
const { hashPassword, calculateDaysBetween, sendSuccess } = require('../utils');
const hashedPassword = await hashPassword(password);
const days = calculateDaysBetween(start, end);
sendSuccess(res, result);
```

## Constants

The utilities use configuration from `config.js` for:
- Working hours (start/end)
- Working hours per day
- Date ranges (min/max)
- JWT settings
- Business rules

This ensures consistency with the centralized configuration system. 