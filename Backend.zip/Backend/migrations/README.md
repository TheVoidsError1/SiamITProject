# Database Migration - Table Updates

This migration adds new columns to the database tables and creates a new leave_used table as requested.

## Recent Migration: Rename request_quota to require_enddate

### Position Table Column Rename
- **Renamed**: `request_quota` → `require_enddate` (BOOLEAN, default: FALSE, NOT NULL)
  - Purpose: Better reflects the column's purpose of requiring end work date
  - Migration files:
    - `rename-request-quota-to-require-enddate.sql` - SQL migration
    - `rename-request-quota-to-require-enddate.js` - Node.js migration script

### How to Run the Column Rename Migration
```bash
cd Backend

# Option 1: Using Node.js script (Recommended)
node migrations/rename-request-quota-to-require-enddate.js

# Option 2: Using SQL file
mysql -u your_username -p your_database_name < migrations/rename-request-quota-to-require-enddate.sql
```

## Changes Made

### Position Table
- **Added**: `new_year_quota` (INT, default: 0, nullable: true)
  - Purpose: Store the new year quota for each position

### Users Table
- **Removed**: `avatar` column
- **Added**:
  - `gender` (VARCHAR(255), nullable: true)
  - `dob` (DATE, nullable: true) - Date of birth
  - `phone_number` (VARCHAR(255), nullable: true)
  - `start_work` (DATE, nullable: true) - Start work date
  - `end_work` (DATE, nullable: true) - End work date

### Admin Table
- **Removed**: `avatar` column
- **Added**:
  - `gender` (VARCHAR(255), nullable: true)
  - `dob` (DATE, nullable: true) - Date of birth
  - `phone_number` (VARCHAR(255), nullable: true)
  - `start_work` (DATE, nullable: true) - Start work date
  - `end_work` (DATE, nullable: true) - End work date

### SuperAdmin Table
- **Removed**: `avatar` column
- **Added**:
  - `gender` (VARCHAR(255), nullable: true)
  - `dob` (DATE, nullable: true) - Date of birth
  - `phone_number` (VARCHAR(255), nullable: true)
  - `start_work` (DATE, nullable: true) - Start work date
  - `end_work` (DATE, nullable: true) - End work date

### New Leave Used Table
- **Created**: `leave_used` table
  - `id` (VARCHAR(36), PRIMARY KEY) - UUID
  - `user_id` (VARCHAR(36), NOT NULL) - Foreign key to users table
  - `leave_type` (VARCHAR(255), NOT NULL) - Type of leave used
  - `days` (INT, DEFAULT 0) - Number of days used
  - `hour` (INT, DEFAULT 0) - Number of hours used
  - `created_at` (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP)
  - `updated_at` (TIMESTAMP, DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

## How to Run the Migration

### Option 1: Using Node.js Scripts (Recommended)
```bash
cd Backend

# Run the table updates migration
node migrations/run-migration.js

# Create the new leave_used table
node migrations/create-leave-used-table.js
```

### Option 2: Using SQL Files
```bash
# Connect to your MySQL database and run:
mysql -u your_username -p your_database_name < migrations/update_tables_2024.sql
mysql -u your_username -p your_database_name < migrations/create_leave_used_table.sql
```

### Option 3: Manual SQL Execution
Copy and paste the SQL commands from the migration files into your MySQL client.

## Prerequisites

1. Make sure your database connection is configured in `config.js`
2. Ensure you have the necessary permissions to alter tables and create new tables
3. Backup your database before running the migration

## Notes

- The migration scripts are designed to be idempotent - they can be run multiple times safely
- If columns already exist or don't exist (for removal), the scripts will skip those operations
- All new columns are nullable to avoid breaking existing data
- The `new_year_quota` column has a default value of 0
- The `leave_used` table includes foreign key constraints and indexes for better performance

## Entity Files Updated

The following entity files have been updated to reflect the new schema:
- `EnityTable/position.js`
- `EnityTable/user.js`
- `EnityTable/admin.js`
- `EnityTable/superadmin.js`
- `EnityTable/leaveUsed.js` (new)

## API Endpoints Created

The following API endpoints are available for the leave_used table:
- `GET /api/leave-used` - Get all leave used records
- `GET /api/leave-used/user/:userId` - Get leave used records by user ID
- `GET /api/leave-used/type/:leaveType` - Get leave used records by leave type
- `GET /api/leave-used/summary/:userId` - Get leave usage summary for a user
- `GET /api/leave-used/statistics` - Get leave usage statistics
- `POST /api/leave-used` - Create new leave used record
- `PUT /api/leave-used/:id` - Update leave used record
- `DELETE /api/leave-used/:id` - Delete leave used record

## Next Steps

After running the migration:
1. Update your application code to handle the new columns
2. Update any API endpoints that create or update these entities
3. Update frontend forms to include the new fields
4. Test the application thoroughly with the new schema
5. Use the new leave_used API endpoints to track leave usage
